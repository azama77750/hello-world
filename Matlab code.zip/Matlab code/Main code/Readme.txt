
This is a Matlab-based program for computing downward continuation, upward continuation, potential, derivatives, and Edge detection of gravity anomaly.

1. Program name: 'Gravity_analysis'.
2. Manuscript title: 'A COMBINATION OF STABLE DOWNWARD CONTINUATION AND EDGE DETECTION APPROACHES TO DELINEATE FAULTS, VOCANIC AND INTRUSIVE ROCKS BOUNDARIES IN SULU SEA REGION'.
3. Authors: Abdu Elazeem Osman Adam Ali*, Zhan Liu, Yongliang Bai, Abdalla Gumaa Farwa, Abboud Suliman  Ahmed, and Guomin Peng
    China University of Petroleum (East China), China; Red Sea University, Sudan; University of Khatoum, Sudan.
   * corresponding author: E-mail: azama77750@yahoo.com