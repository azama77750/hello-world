function Gravity_analysis()

% A code for performing field continuation, full gradient tensor and edge detection. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
clear all;close all;clc

global G 

format long

G.G1 =6.67E-11;% Universal gravitational constant.
r=1;  %Raduis of sphere.
G.g=1E5*G.G1*4*pi*r^3/3; % constant.
G.n=500; % Number of grided points at each horizontal axis (x- and y-axis).
G.ord=5; % Mean filter order.
G.err=10; % An accuracy of equivalent source optimum depth.

% main window inicialization. Modified from Pasteka, et al. (2012).
mainwindow=figure('Name','GRAVITY ANALYSIS','NumberTitle','off');
bg=get(mainwindow,'Color');
[pic,map]=imread('background.rlg','BackgroundColor',bg);
image(pic);colormap(map);axis image;axis off

set((gca(mainwindow)),'position',[0.02 0.02 .97 .97])

%main window parameters. Modified from Pasteka, et al. (2012).
set(mainwindow,'Menubar','none','Resize','off','Position',[400,200,500,400])

%navigation bar set up. Modified from Pasteka, et al. (2012).
   
menu1 = uimenu('Label','Load data');
        uimenu(menu1,'Label','Compute equivalent source','Callback',@Compute_equivalent_source);
        uimenu(menu1,'Label','Open and display data','Callback',@Display_grid_data_Callback);
        uimenu(menu1,'Label','Filter data','Callback',@Filtering_data);
        uimenu(menu1,'Label','Minima and maxima','Callback',@Local_max_min_gravity_magnetic_refined2);
      
menu2 = uimenu('Label','Synthetic data');
        uimenu(menu2,'Label','Graity effect of sphere','Callback',@sphere_gravity_effect);
        uimenu(menu2,'Label','Graity effect of rectangular prism','Callback',@prism_gravity_effect);
        
menu3 = uimenu('Label','Data analysis');
        uimenu(menu3,'Label','Downward continuation','Callback',@Downward_contiuation);
        uimenu(menu3,'Label','Upward continuation','Callback',@Upward_contiuation);
        uimenu(menu3,'Label','Gravity potential','Callback',@Gravity_potential);
        uimenu(menu3,'Label','Vertical integration','Callback',@Vertical_integration);
        uimenu(menu3,'Label','Vertical_deivative','Callback',@Vertical_deivative);
        uimenu(menu3,'Label','X-Horizontal deivative','Callback',@Horizontal_deivative_x);
        uimenu(menu3,'Label','Y-Horizontal deivative','Callback',@Horizontal_deivative_y);
        uimenu(menu3,'Label','Total Horizontal deivative','Callback',@Total_Horizontal_deivative);
        uimenu(menu3,'Label','Gravity edge detection','Callback',@Gravity_edge_detections);
        
        
menu4 = uimenu('Label','About');
        uimenu(menu4,'Label','About','Callback',@about);   
        
 %%=============================================================

function [nwx,nwy,qz,qz2]=grid_data(dta,n)

% A function for gridding scattered data into uniformly spaced data. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long
G.minx = 0; G.maxx= 0; G.miny = 0; G.maxy= 0; 
G.dx=0; G.dy=0;G.minf = 0; G.maxf= 0;

G.minf=min(dta(:,3));% minimum value of the data.
G.maxf=max(dta(:,3));% maximum value of the data.
G.minx=min(dta(:,1));% minimum value in x-coordinates.
G.maxx=max(dta(:,1));% maximum value in x-coordinates.
G.miny=min(dta(:,2));% minimum value in y-coordinates.
G.maxy=max(dta(:,2));% maximum value in y-coordinates.
G.dx=(G.maxx-G.minx)/(n-1);% spacing along x-axis (matrix columns).
G.dy=(G.maxy-G.miny)/(n-1);% spacing along y-axis (matrix columns).

nwx=G.minx:G.dx:G.maxx;% X-coordinates array.
nwy=G.miny:G.dy:G.maxy;% Y-coordinates array.

% Gridding process.
F = TriScatteredInterp(dta(:,1), dta(:,2), dta(:,3),'natural');
[qx,qy] = meshgrid(nwx,nwy);
qz = F(qx,qy);

[mm nn]=size(dta);
[G.rowsm,G.columnsn]=size(qz);
if nn>=4
    F = TriScatteredInterp(dta(:,1), dta(:,2), dta(:,4),'natural');
    [qx,qy] = meshgrid(nwx,nwy);
    qz2 = F(qx,qy);
else
   
    qz2 =zeros(G.rowsm,G.columnsn);
end

G.m11=G.rowsm*G.columnsn;
%% ===========================================

function Read_data(input1,n)

% A function for reading a text format data file. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

[G.name,G.path] = uigetfile('*.txt',input1);
cdir=pwd;cd(G.path)
G.dta0 = dlmread(G.name);
cd(cdir)

[G.row,G.colm]=size(G.dta0);
n=sqrt(G.row);
G.n1=n;
% Gridding the data.
% G.dta0 is an input data matrix.
% G.xax is X-coordinates array.
% G.yax is y-coordinates array.
% G.dta1 is gravity data matrix.
% G.dta2 is observation plane height.
[G.xax,G.yax,G.dta1,G.dta2]=grid_data(G.dta0,G.n1);
if G.m11<G.row
G.dta0=G.dta0(1:G.m11,:);
end
for i=1:G.rowsm
    for j=1:G.columnsn
        G.dta0(j+G.columnsn*(i-1),1)=G.xax(j);
        G.dta0(j+G.columnsn*(i-1),2)=G.yax(i);
        G.dta0(j+G.columnsn*(i-1),3)=G.dta1(i,j);
        G.dta0(j+G.columnsn*(i-1),4)=G.dta2(i,j);
    end
end
maxmindiff=max(G.dta0(:,4))-min(G.dta0(:,4));
if maxmindiff==0
    G.dt=G.dta0(:,4);
else
    G.dt=zeros(length(G.dta0(:,4)),1);
end

%% ======================================================================


function Display_grid_data_Callback(input1,input2)
% Modified from Pasteka, et al. (2012).

global G
format long

input1='Select the input text file';
Read_data(input1,G.n);
 tit=G.name(1:length(G.name)-4);   
% plotting the contour map of the readed input grid data
orig_fig_g=figure('Name',tit ,'NumberTitle','off');
pcolor(G.xax,G.yax,G.dta1); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title(tit )
colormap(gca(orig_fig_g),colscale)
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate)
set(get(cb,'ylabel'),'string','Change to a suitable unit')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
function Compute_equivalent_source(input1,input2)

% A function for computing equivalent source densities from gravity data. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic

global G
format long

prompt = {'Enter lithosphere thickness for real Bouguer gravity data or the depth to the botton surface of the deepest source for synthetic data in meters'};
thick = inputdlg(prompt,'input parameter');

input3='Select the orignal Bouguer anomaly text file';
Read_data(input3,G.n);
Zt = abs(str2double(thick));% lithosphere thickness.
Zst=G.dx/2; Zend=Zt;  % Lower and upper bound of the equivalent source depth
% for golden section search algorithm.

alpha=golden_section_gravity2( Zst,Zend);% Golden section search algorithm function.
DepthRMS=[G.z1;alpha;G.count;toc];% Array contains equivalent source optimum depth 
% (G.z1), minimum root mean squared error (alpha), equivalent sources
% number (G.count) and computation time (toc).
MD=[G.dta0 [G.MDL;nan(G.diff,4)] [DepthRMS;nan(G.m11-4,1)]];% Effectie discrete equivalent
% sources densities (output file).
G.dta0=MD;
save([G.path 'Effect discrete equivalent sources.txt'], 'MD', '-ASCII');
time=num2str(toc);
msgbox(['The ellapsed time is: ' time ' seconds'],'message');

%%


function Filtering_data(input1,input2)

% A function for filtering noisy data. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

choice1 = questdlg('Filter name','Select filter name', ...
	'Mean filter','Butterworth filter','Mean filter');
switch choice1
    case 'Mean filter'   
        prompt = {'Enter filter order (1, 2, 3,...'};
        order = inputdlg(prompt,'input parameter');
        ord=abs(str2double(order));
        input1='Select the input text file';
        Read_data(input1,G.n);
        [G.efield,G.numextrRows,G.numextrCols] = cosxp2(G.dta1,0.5);% 0.5=50% of extrapolation
        [G.erowsm, G.ecolumnsn] = size(G.efield);
        flt=ones(ord)/(ord^2);
        G.efield=filter2(flt,G.efield);% Filtered data.
        G.dta1 = G.efield(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);
        filtr='Mean filtered ';
    case 'Butterworth filter'
        choice = questdlg('Filter type','Select filter type', ...
            'Low-pass','High-pass','Low-pass');
        switch choice
            case 'Low-pass'
                prompt = {'Enter filter order (1, 2, 3,...','Enter cutoff frequencies (between zero and 1)'};
                ordercut = inputdlg(prompt,'input parameter');
                ordcut=abs(str2double(ordercut));
                ord=ordcut(1);
                cut=ordcut(2);
                input1='Select the input text file';
                Read_data(input1,G.n);
                flt=Butterworth_HighPass(ord, cut);
                filt=(1-flt).*G.y;
                G.efield=real(ifft2(filt));
                G.dta1 = G.efield(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);
                filtr='Butter low-pass filtered ';
            case 'High-pass'
                prompt = {'Enter filter order (1, 2, 3,...','Enter cutoff frequencies (between zero and 1)'};
                ordercut = inputdlg(prompt,'input parameter');
                ordcut=abs(str2double(ordercut));
                ord=ordcut(1);
                cut=ordcut(2);
                input1='Select the input text file';
                Read_data(input1,G.n);
                flt=Butterworth_HighPass(ord, cut);
                filt=(flt).*G.y;
                G.efield=real(ifft2(filt));
                G.dta1 = G.efield(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);
                filtr='Butter high-pass filtered ';
        end
end

filt2=G.dta0; 
for i=1:G.rowsm
    for j=1:G.columnsn
        filt2(j+G.columnsn*(i-1),3)=G.dta1(i,j);
    end
end
tit=G.name(1:length(G.name)-4);
save([G.path filtr G.name], 'filt2', '-ASCII');

% Display data in 2D view.
orig_fig_g=figure('Name',[filtr tit],'NumberTitle','off');
pcolor(G.xax,G.yax,G.dta1); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title([filtr tit])
colormap(gca(orig_fig_g),colscale)
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate)
set(get(cb,'ylabel'),'string','Change to a suitable unit')
%% ======================================================================

function flt=Butterworth_HighPass(ord, cut)

% A function for filtering noisy data. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long
% ord is filter order.
% cut is cutoff frequencies.
% [x y]=meshgrid(-floor(G.erowsm/2):floor((G.erowsm-1)/2),-floor(G.ecolumnsn/2):floor((G.ecolumnsn-1)/2));
FFT_wavnum();
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*ord));



function x = conjgrad2(A,b,x)

% An iterative conjugate gradient algorithm function for solving linear
% systems such as Ax = b. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


format long

% A is squared positive definite matrix.
% b is data array.
% x is the required solution array (model density array).


    r=b-A*x; % r is a residual array.
    p=r;
    rtr=r'*r;
   for i=1:length(b)
        q=A*p;
        alpha4=rtr/(p'*q);
        x=x+alpha4*p;
        rtrold=rtr;
        r=r-alpha4*q;
        rtr=r'*r;
        beta=rtr/rtrold;
        p=r+beta*p;
   end
   
   
%%

function MDL = Gauss_Jordan( a )

% A function of Gauss-Jordan method for solving linear systems. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The linear system is Ap=d. A is a plynomial coefficient matrix, d is the data, and
% p is the required solution array. a = [ A  d];

[m,n]=size(a);
for j=1:m-1
    for z=2:m
        if a(j,j)==0
            t=a(j,:);a(j,:)=a(z,:);
            a(z,:)=t;
        end
    end
    for i=j+1:m
        a(i,:)=a(i,:)-a(j,:)*(a(i,j)/a(j,j));
    end
end
x=zeros(1,m);
for j=m:-1:2
    for i=j-1:-1:1
        a(i,:)=a(i,:)-a(j,:)*(a(i,j)/a(j,j));
    end
end
for s=1:m
    a(s,:)=a(s,:)/a(s,s);
    x(s)=a(s,n);
end

MDL=x';


%%
function plyn_4th_ord()

% A function for approximating the residual anomaly based on polynomial method. 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

A = zeros(G.m11,15);% Polynomial coefficient matrix.
for i=1:G.m11
    A(i,1)=1;A(i,2)=G.dta0(i,1);A(i,3)=G.dta0(i,2);A(i,4)=G.dta0(i,1)^2;
    A(i,5)=G.dta0(i,1)*G.dta0(i,2);A(i,6)=G.dta0(i,2)^2;A(i,7)=G.dta0(i,1)^3;
    A(i,8)=G.dta0(i,1)^2*G.dta0(i,2);A(i,9)=G.dta0(i,1)*G.dta0(i,2)^2;
    A(i,10)=G.dta0(i,2)^3;A(i,11)=G.dta0(i,1)^4;A(i,12)=G.dta0(i,1)^3*G.dta0(i,2);
    A(i,13)=G.dta0(i,1)^2*G.dta0(i,2)^2;A(i,14)=G.dta0(i,1)*G.dta0(i,2)^3;
    A(i,15)=G.dta0(i,2)^4;
    
end
% A1 is squared positive definite matrix.
A1=(A'*A);
B=A'*G.dta0(:,3);
AB=[A1 B];
MDL = Gauss_Jordan( AB );
Reg=A*MDL;
Reg1=G.dta0;
Reg1(:,3)=Reg;% Estimated regional anomaly.
resid=G.dta0;
resid(:,3)=G.dta0(:,3)-Reg1(:,3);% Estimated residual anomaly.
G.resid=zeros(G.rowsm,G.columnsn);
for i=1:G.rowsm
    for j=1:G.columnsn
        G.resid(i,j)=resid(j+G.columnsn*(i-1),3);
    end
end


%% =============================================================================


function Local_max_min_gravity_magnetic_refined()

% A code for determining the effective discrete equivalent sources. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

%===========================================================
% Estimate residial anomaly.
plyn_4th_ord();

% Deternimation of minima and maxima of the etimated residual anomaly to 
% determine an equivalent source assembly in the most anomalous areas.
condition =8;
count0=0;
str=8;nd=1-str;

for i=str:G.rowsm+nd
	  for j=str:G.columnsn+nd
          
            if ((G.resid(i,j) > G.resid(i,j-1)) && (G.resid(i,j) > G.resid(i,j+1)))||...
               ((G.resid(i,j) > G.resid(i-1,j)) && (G.resid(i,j) > G.resid(i+1,j)))||...
               ((G.resid(i,j) > G.resid(i-1,j+1)) && (G.resid(i,j) > G.resid(i+1,j-1)))||...
               ((G.resid(i,j) > G.resid(i-1,j-1)) && (G.resid(i,j) > G.resid(i+1,j+1)))||...
               ((G.resid(i,j) < G.resid(i,j-1)) && (G.resid(i,j) < G.resid(i,j+1)))||...
               ((G.resid(i,j) < G.resid(i-1,j)) && (G.resid(i,j) < G.resid(i+1,j)))||...
               ((G.resid(i,j) < G.resid(i-1,j+1)) && (G.resid(i,j) < G.resid(i+1,j-1)))||...
               ((G.resid(i,j) < G.resid(i-1,j-1)) && (G.resid(i,j) < G.resid(i+1,j+1)))
           
               count0=count0+1;
               gmn0(count0,1)=G.xax(j);
               gmn0(count0,2)=G.yax(i);
               gmn0(count0,3)=G.resid(i,j);
               gmn0(count0,4)=j-(str-1)+G.columnsn*(i-str);
            end
            
    end
end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
count=0;
for i=1:condition:count0
    if gmn0(i,3)~=0
        count=count+1;
        gmn(count,1)=gmn0(i,1);
        gmn(count,2)=gmn0(i,2);
        gmn(count,3)=gmn0(i,3);
        gmn(count,4)=gmn0(i,4);
    end
end
%==========================================================================
% G.MDL is the equivalent sources location matix.
G.count=count;G.MDL=gmn;G.diff=G.m11-count;


%% =========================================================================


function Local_max_min_gravity_magnetic_refined2(input1,input2)

% A fuction for reading data, determining the effective discrete equivalent sources, 
% and save the output data file as minima and maxima. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

input3='Select the data text file';
Read_data(input3,G.n);

Local_max_min_gravity_magnetic_refined();
gmn=G.MDL;
save([G.path 'minima and maxima.txt'],'gmn','-ascii');

%%

function A = coefficient_matrix(b)

% A function for calculating the coefficient matrix of gravity data. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long
%%

% G.g is a constant includes gravitational constant and sphere volume.
% G.m11 is the total number of data points.
% G.columnsn is number of data points along x-direction (matrix columns number).
% G.rowsm is number of data points along y-direction (matrix rows number).
% G.MDLindex is a matrix contains the indices of the minima and maxima.
% G.count is the total number of the local minima and maxima.
G.MDLindex=G.MDL(:,4);
A=zeros(G.m11,G.count);% Coefficient matrix.
for j=1:G.count
    c=rem(G.MDLindex(j),G.columnsn);k=-1;
    if c==0
        c=G.columnsn;
    end
    for i1=1:G.rowsm
      l=1;l1=1;
      for j1=1:G.columnsn
          i=j1+(i1-1)*G.columnsn;
          if i<=G.MDLindex(j)
          if j1<=c
              k=k+1;A(i,j)=b(G.MDLindex(j)-k);
          elseif j1>c
              f=G.MDLindex(j)+2*l+1-i;A(i,j)=b(f);l=l+1;k=k+1;
          end
              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          elseif i>=G.MDLindex(j)
              if j1<c
              f=i-G.MDLindex(j)-2*l1+1+2*c;A(i,j)=b(f);l1=l1+1;   
          elseif j1>=c
              f=i+1-G.MDLindex(j);A(i,j)=b(f); 
              end
          end
      end
    end
end


function A = gravity_coefficient_matrix_modified2(z1)

% A function for calculating the coefficient matrix of gravity data. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long
%%
b=zeros(G.m11,1);% The gravity field the first source at all obseration points.
for ii=1:G.m11
   b(ii)= (z1-G.dt(ii))*G.g/(((G.dta0(ii,1)-G.dta0(1,1) )^2 + (G.dta0(ii,2)-G.dta0(1,2))^2 + (z1-G.dt(ii))^2)^(3/2));
end
A = coefficient_matrix(b);



%%

function  [MDL1,alpha1,CalcDAT1]  = calc_alpha_gravity2( Z2)

% A function for solving linear system and estimating RMS. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G

format long

A = gravity_coefficient_matrix_modified2(Z2);% Gravity coefficient matrix.

A1=(A'*A);% Poisitive squared matrix.
B=A'*G.dta0(:,3);% Gravity data array.
x=B;% Initial model density array.
MDL1=conjgrad2(A1,B,x);% Final model density array.
CalcDAT1=A*MDL1;% Calculated data array
alpha1=sqrt(sum((G.dta0(:,3)-CalcDAT1).^2));% A parmeter for RMS calculation.



%% ==========================================================================


function alpha=golden_section_gravity2( a,b )

% A function for iteratively calculating the optimum depth of the discrete equivalent 
% sources level by using a combination of conjugate gradient and golden section search 
% algorithms. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


global G
format long
%%

tau=0.618;      % golden proportion coefficient, around 0.618
x1=a+(1-tau)*(b-a);    % computing lower limit of the dependent variable.
x2=a+tau*(b-a);   % computing upper limit of the dependent variable.
IterDepRMS=zeros(3); % Iteration number matrix.

msgbox('This process may takes long time, please wait !','message');
Local_max_min_gravity_magnetic_refined();
[MDL1,alpha1,CalcDAT1]  = calc_alpha_gravity2( x1);               

iteration=1;
IterDepRMS(iteration,1)=iteration;IterDepRMS(iteration,2)=x1;IterDepRMS(iteration,3)=alpha1/G.m11;
[MDL2,alpha2,CalcDAT2]  = calc_alpha_gravity2( x2);
iteration=iteration+1;
IterDepRMS(iteration,1)=iteration;IterDepRMS(iteration,2)=x2;IterDepRMS(iteration,3)=alpha2/G.m11;

%%
% The golden sereach section algorithm.
while ((abs(b-a)>G.err)) 
    if(alpha1<alpha2)
        b=x2;
        x2=x1;
        alpha2=alpha1;
        x1=a+(1-tau)*(b-a);
        [MDL1,alpha1,CalcDAT1]  = calc_alpha_gravity2( x1);  
        iteration=iteration+1;
        IterDepRMS(iteration,1)=iteration;IterDepRMS(iteration,2)=x1;IterDepRMS(iteration,3)=alpha1/G.m11;
    else
        a=x1;
        x1=x2;
        alpha1=alpha2;
        x2=a+tau*(b-a);
        [MDL2,alpha2,CalcDAT2]  = calc_alpha_gravity2( x2);
        iteration=iteration+1;
        IterDepRMS(iteration,1)=iteration;IterDepRMS(iteration,2)=x2;IterDepRMS(iteration,3)=alpha2/G.m11;
     end
end
CalcDAT=G.dta0;

% Selecting minimum RMS.
% G.z1 is the optimum depth of equivalent sources plane.
% alpha is the minimum RMS.
if(alpha1<alpha2)
    G.z1=x1;alpha=alpha1/G.m11;G.MDL(:,3) = MDL1;CalcDAT(:,3)=CalcDAT1;
    
elseif (alpha1>alpha2)
    G.z1=x2;alpha=alpha2/G.m11;G.MDL(:,3) = MDL2;CalcDAT(:,3)=CalcDAT2;
    
    else
    G.z1=(x1+x2)/2;
    [MDL3,alpha3,CalcDAT3]  = calc_alpha_gravity2( G.z1);
    alpha=alpha3/G.m11;G.MDL(:,3) = MDL3;CalcDAT(:,3)=CalcDAT3;
    iteration=iteration+1;
    IterDepRMS(iteration,1)=iteration;IterDepRMS(iteration,2)=G.z1;IterDepRMS(iteration,3)=alpha/G.m11;
    
end

save([G.path 'Iterations.txt'], 'IterDepRMS', '-ASCII');
%
save([G.path 'Calculated gravity anomaly.txt'], 'CalcDAT', '-ASCII');


%==========================================================================


function downward=Downward_contiuation(input1,input2)

% A function for calculating downward continued gravity anomaly.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

choice = questdlg('Do the data have pre-computed equivalent source file?', ...
	'Equivalent source data file', ...
	'Yes','No','No');
switch choice
case 'Yes'   
prompt = {'Enter the downward continuation depth in meters'};
answer = inputdlg(prompt,'input parameter');
hinputstr = answer; h = abs(str2double(hinputstr)); % Downward continuation depth.
input1='Select the (Effect discrete equivalent sources.txt) file';
Read_data(input1,G.n);
G.count =G.dta0(3,9);% Equivalent sources number.
G.MDL = G.dta0(1:G.count,5:8);% Equivalent sources densities and locations.
ze = G.dta0(1,9);% Equivalent sources optimum depth.
G.z=ze-h;% Continuation level relative to the equivalent source optimum depth.

case 'No'
    prompt = {'Enter the downward continuation depth in meters'};
    answer = inputdlg(prompt,'input parameter');
    hinputstr = answer; h = abs(str2double(hinputstr)); 
    Compute_equivalent_source(input1,input2);
    G.z=G.z1-h;
end

A = gravity_coefficient_matrix_modified2(G.z);
dwn=G.dta0;
dwn(:,3)=A*G.MDL(:,3);
dwn(5,9)=h;
save([G.path num2str(h) ' m Downward continued gravity anomaly.txt'], 'dwn', '-ASCII');

[G.xax,G.yax,G.dwn]=grid_data(dwn,G.n);

orig_fig_g=figure('Name','Downward continuation','NumberTitle','off');
pcolor(G.xax,G.yax,G.dwn); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title({'Downward continued gravity anomaly', ['continuation depth = ' num2str(h) ' m']});
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal');

downward=(['of the ' num2str(h) ' m downward continued anomaly']);


%%
function upward=Upward_contiuation(input1,input2)

% A function for calculating downward continued gravity anomaly.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

choice = questdlg('Do the data have pre-computed equivalent source file?', ...
	'Equivalent source data file', ...
	'Yes','No','No');
switch choice
case 'Yes'       
prompt = {'Enter the upward continuation depth in meters'};
answer = inputdlg(prompt,'input parameter');
hinputstr = answer; h = abs(str2double(hinputstr)); % Upward continuation height.
input1='Select the (Effect discrete equivalent sources.txt) file';
Read_data(input1,G.n);
G.count =G.dta0(3,9);% Equivalent sources number.
G.MDL = G.dta0(1:G.count,5:8);% Equivalent sources densities and locations.
ze = G.dta0(1,9);% Equivalent sources optimum depth.
G.z=ze+h;% Continuation level relative to the equivalent source optimum depth.

case 'No'
    prompt = {'Enter the upward continuation depth in meters'};
    answer = inputdlg(prompt,'input parameter');
    hinputstr = answer; h = abs(str2double(hinputstr)); 
    Compute_equivalent_source(input1,input2);    
    G.z=G.z1+h;
end

A = gravity_coefficient_matrix_modified2(G.z);
up=G.dta0;
up(:,3)=A*G.MDL(:,3);
up(5,9)=h;
save([G.path num2str(h) ' m Upward continued gravity anomaly.txt'], 'up', '-ASCII');
[G.xax,G.yax,G.up]=grid_data(up,G.n);
orig_fig_g=figure('Name','Upward continuation','NumberTitle','off');
pcolor(G.xax,G.yax,G.up); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title({'Upward continued gravity anomaly', ['continuation height = ' num2str(h) ' m']});
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal');
upward=(['of the ' num2str(h) ' m upward continued anomaly']);


function A = gravity_potential_coefficient_matrix_modified2(z1)

% A function for calculating the coefficient matrix of gravity potential data.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long
%%

b=zeros(G.m11,1);% The gravity potential the first source at all obseration points.
for ii=1:G.m11
   b(ii)= G.g/(((G.dta0(ii,1)-G.dta0(1,1) )^2 + (G.dta0(ii,2)-G.dta0(1,2))^2 + (z1-G.dt(ii))^2)^(1/2));
end

A = coefficient_matrix(b);

%% ======================================================================

function downward=Gravity_potential( input1,input2)

% A function for calculating gravity potential anomaly.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
choice = questdlg('Select the data type you want to process:', ...
	'Data type to be processed', ...
	'Original Bouguer anomaly','Downward continued anomaly','Original Bouguer anomaly');
switch choice
case 'Original Bouguer anomaly'  
    choice2 = questdlg('Do the data have pre-computed equivalent source file?', ...
	'Equivalent source data file', ...
	'Yes','No','No');
 switch choice2
    case 'Yes'

input1='Select the (Effect discrete equivalent sources.txt) file';
Read_data(input1,G.n);  
G.count =G.dta0(3,9);% Equivalent sources number.
G.MDL = G.dta0(1:G.count,5:8);% Equivalent sources densities and locations.
G.z = G.dta0(1,9);% Continuation level relative to the equivalent source optimum depth.
downward=('of the original anomaly');
potent=({'gravity potential', downward});

case 'No'
Compute_equivalent_source(input1,input2);
G.z=G.z1;
downward=('of the original anomaly');
potent=({'gravity potential', downward});
 end
case 'Downward continued anomaly'  
    choice2 = questdlg('Do the downward continued data available?', ...
	'Import downward continued data', ...
	'Yes','No','No');
 switch choice2
    case 'Yes'

input1='Select the downward text file (*** m Downward continued gravity anomaly.txt)';
Read_data(input1,G.n);  
G.count =G.dta0(3,9);
G.MDL = G.dta0(1:G.count,5:8);
ze = G.dta0(1,9);
h =G.dta0(5,9);
G.z=ze-h;
downward=(['of the ' num2str(h) ' m downward continued anomaly']);
potent=({'gravity potential', downward});

case 'No'
        
        downward=Downward_contiuation(input1,input2);
        G.dta1=G.dwn;
        potent=({'gravity potential', downward});
 end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ap = gravity_potential_coefficient_matrix_modified2(G.z);
ptnl=G.dta0;
ptnl(:,3)=Ap*G.MDL(:,3);
save([G.path 'Gravity potential ' downward '.txt'], 'ptnl', '-ASCII');
G.ptnl=ptnl;
[G.xax,G.yax,G.ptnl2]=grid_data(ptnl,G.n);
orig_fig_g=figure('Name','Gravity potential','NumberTitle','off');
pcolor(G.xax,G.yax,G.ptnl2); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title(potent);
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal.m');


%% =======================================================================
function downward =Vertical_integration( input1,input2 )

% A function for calculating gravity potential anomaly.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

%=======================================================================
choice = questdlg('Select the data type you want to process:', ...
	'Data type to be processed', ...
	'Original Bouguer anomaly','Downward continued anomaly','Original Bouguer anomaly');
switch choice
case 'Original Bouguer anomaly'       
input1='Select the Original Bouguer anomaly text file';
Read_data(input1,G.n); 
downward=('of the original anomaly');
potent=({'gravity vertical integration ', downward});
case 'Downward continued anomaly'  
    choice2 = questdlg('Do the downward continued data available?', ...
	'Import downward contiued data', ...
	'Yes','No','No');
 switch choice2
    case 'Yes'
        input1='Select the downward text file (*** m Downward continued gravity anomaly.txt)';
        Read_data(input1,G.n); 
        h =G.dta0(5,9);% Downward continuation depth.

        downward=(['of the ' num2str(h) ' m downward continued anomaly']);
        potent=({'gravity vertical integration', downward});
    case 'No'
        downward=Downward_contiuation(input1,input2);
        potent=({'gravity vertical integration', downward});
        G.dta1=G.dwn;
  end
end
%==============================================================================
FFT_wavnum();
% G.y is FFT of the Bouguer or downward continued data. 
% G.fkx is x-coordinates array in wavenumber domain.
% G.fky is y-coordinates array in wavenumber domain.
% 
G.vintg=zeros(G.erowsm, G.ecolumnsn);% FFT of vertical integration values (expanded sized matrix).
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
        if G.fkx(j)==0&&G.fky(i)==0
            G.fkx(j)=1e-6;G.fky(i)=1e-6;
        end
        G.vintg(i,j)=(G.y(i,j)/(sqrt(G.fkx(j)^2+G.fky(i)^2)));
    end
end

finalvintg = real(ifft2(G.vintg));% Vertical integration values (expanded sized matrix).

% Returning back to the original data size
G.finalvintg2 = finalvintg(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);
% G.finalvintg2 is the vertical integration values (original sized matrix).
Vint=G.dta0;
for i=1:G.rowsm
    for j=1:G.columnsn
        Vint(j+G.columnsn*(i-1),3)=G.finalvintg2(i,j);
    end
end

save([G.path 'Gravity vertical integration ' downward '.txt'], 'Vint', '-ASCII');
G.Vint=Vint;
[G.xax,G.yax,G.intg]=grid_data(Vint,G.n);
orig_fig_g=figure('Name','Gravity Vertical integration','NumberTitle','off');
pcolor(G.xax,G.yax,G.intg); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title(potent);
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal.m');

%% =======================================================================

function FFT_wavnum()

% A function for calculating Fast Fourier Transform of data.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

[G.efield,G.numextrRows,G.numextrCols] = cosxp2(G.dta1,0.4);% 0.4=40% of extrapolation
% new dimensions of the extrapolated field
[G.erowsm, G.ecolumnsn] = size(G.efield);
G.y = fft2(G.efield);

% dfx and dfy are the steps of the wave-numbers
% G.fkx is x-coordinates in wave-nimber domain.
% G.fky is y-coordinates in wave-nimber domain.
G.dx = abs(G.maxx-G.minx)/(G.columnsn-1); G.dy = abs(G.maxy-G.miny)/(G.rowsm-1);
G.dfx = (2*pi)/(G.dx*(G.ecolumnsn-1)); G.dfy = (2*pi)/(G.dy*(G.erowsm-1));
R=rem(G.ecolumnsn,2);
if R==0
       G.fkx(1:G.ecolumnsn/2+1) = 0:G.dfx:(G.ecolumnsn/2)*G.dfx;
       fkx_pom = -G.fkx(2:G.ecolumnsn/2+1);
       G.fkx(G.ecolumnsn/2+1:G.ecolumnsn) = fkx_pom(:,(length(fkx_pom):-1:1));
else
       G.fkx(1:round(G.ecolumnsn/2))=0:G.dfx:floor(G.ecolumnsn/2)*G.dfx;
       fkx_pom = -G.fkx(2:round(G.ecolumnsn/2));
       G.fkx(round(G.ecolumnsn/2)+1:G.ecolumnsn) = fkx_pom(:,(length(fkx_pom):-1:1));
end;
R=rem(G.erowsm,2);
if R==0
       G.fky(1:G.erowsm/2+1) = 0:G.dfy:(G.erowsm/2)*G.dfy;
       fky_pom = -G.fky(2:G.erowsm/2+1);
       G.fky(G.erowsm/2+1:G.erowsm) = fky_pom(:,(length(fky_pom):-1:1));
else
       G.fky(1:round(G.erowsm/2))=0:G.dfy:floor(G.erowsm/2)*G.dfy;
       fky_pom = -G.fky(2:round(G.erowsm/2));
       G.fky(round(G.erowsm/2)+1:G.erowsm) = fky_pom(:,(length(fky_pom):-1:1));
end  


%% =================================================================

function Vertical_derivative(n)

% A function for calculating vertical derivative of gravity anomaly.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

%=======================================================================
% n is the derivative order.
FFT_wavnum();
fftvd=zeros(G.erowsm, G.ecolumnsn);% FFT of vertical derivative values (expanded sized matrix).
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftvd(i,j)=(G.y(i,j)*(sqrt(G.fkx(j)^2+G.fky(i)^2))^n);
    end
end
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*fftvd;
finalvd=real(ifft2(filt));
%==========================================================================

% Returning back to the original matrix size
G.finalvd = finalvd(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);



%% =================================================================

function Vertical_deivative( input1,input2 )

% A function for calculating vertical derivative of gravity anomaly.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long

%=======================================================================

prompt = {'Enter the derivative order:'};
answer = inputdlg(prompt,'input parameter');
hinputstr = answer; n = abs(str2double(hinputstr)); 
%===========================================================
   
input1='Select the data text file';
Read_data(input1,G.n); 
downward=G.name(1:length(G.name)-4);

Vertical_derivative(n);

Vd=G.dta0;% Vertical derivative (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        Vd(j+G.columnsn*(i-1),3)=G.finalvd(i,j);
    end
end

if n==1
   ord=([num2str(n) 'st order ']); 
elseif n==2
    ord=([num2str(n) 'nd order ']);
elseif n==3
    ord=([num2str(n) 'rd order ']);
else
    ord=([num2str(n) 'th order ']);
end

save([G.path ord 'Vertical deivative ' downward '.txt'], 'Vd', '-ASCII');

[G.xax,G.yax,G.Vd]=grid_data(Vd,G.n);
orig_fig_g=figure('Name','Gravity potential','NumberTitle','off');
pcolor(G.xax,G.yax,G.Vd); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title({[ord 'Vertical deivative'], downward});
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal.m');



%===================================================================
function Horizontal_deivative_x( input1,input2 )

% A function for calculating horizontal derivative of gravity anomaly at x-direction.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long
%% ===================================================
input1='Select the data text file';
Read_data(input1,G.n); 

%=======================================================================
prompt = {'Enter the derivative order:'};
answer = inputdlg(prompt,'input parameter');
hinputstr = answer; n = abs(str2double(hinputstr)); 
%===========================================================
choice = questdlg('Select the derivative method:', ...
	'The derivative method', ...
	'FFT-based','Spline-based','FFT-based');
switch choice
case 'FFT-based'       

FFT_wavnum();
ffthdx=zeros(G.erowsm, G.ecolumnsn);% FFT of x-horizontal derivative values (expanded sized matrix).
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            ffthdx(i,j)=(G.y(i,j)*((1i)^n*(G.fkx(j))));
    end
end

cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*ffthdx;
finalhdx=real(ifft2(filt));% Filtered x-horizontal derivative values (expanded sized matrix).

% Returning back to the original grid size
% G.finalhdx is x-horizontal derivative values (original sized matrix)..
G.finalhdx = finalhdx(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);


finalhdx2=G.dta0;% x-horizontal derivative (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        finalhdx2(j+G.columnsn*(i-1),3)=G.finalhdx(i,j);
    end
end


case 'Spline-based'  
    % x-horizontal derivative in space domain.
    [finalhdx2,Gxz] = Gzx_Gxz_dta_space( G.dta0,G.n1 );
end
%==============================================================================
downward=G.name(1:length(G.name)-4);

if n==1
   ord=([num2str(n) 'st order ']); 
elseif n==2
    ord=([num2str(n) 'nd order ']);
elseif n==3
    ord=([num2str(n) 'rd order ']);
else
    ord=([num2str(n) 'th order ']);
end

save([G.path ord 'X-horizontal deivative of the ' downward '.txt'], 'finalhdx2', '-ASCII');

[G.xax,G.yax,G.hdx]=grid_data(finalhdx2,G.n);
orig_fig_g=figure('Name','Gravity potential','NumberTitle','off');
pcolor(G.xax,G.yax,G.hdx); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title({[ord 'X-horizontal deivative'], downward});
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal.m');



%===================================================================
function Horizontal_deivative_y( input1,input2 )

% A function for calculating horizontal derivative of gravity anomaly at y-direction.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global G
format long
%% ===================================================
input1='Select the data text file';
Read_data(input1,G.n); 

%=======================================================================
prompt = {'Enter the derivative order:'};
answer = inputdlg(prompt,'input parameter');
hinputstr = answer; n = abs(str2double(hinputstr)); 
%===========================================================
choice = questdlg('Select the derivative method:', ...
	'The derivative method', ...
	'FFT-based','Spline-based','FFT-based');
switch choice
case 'FFT-based'       

FFT_wavnum();
ffthdy=zeros(G.erowsm, G.ecolumnsn);% FFT of x-horizontal derivative values (expanded sized matrix)..
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            ffthdy(i,j)=(G.y(i,j)*((1i)^n*(G.fky(i))));
    end
end
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*ffthdy;
finalhdy=real(ifft2(filt));% Filtered x-horizontal derivative values (expanded sized matrix).

% Returning back to the original grid size
% G.finalhdy is y-horizontal derivative values (original sized matrix)..
G.finalhdy2 = finalhdy(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);


finalhdy2=G.dta0;% y-horizontal derivative (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        finalhdy2(j+G.columnsn*(i-1),3)=G.finalhdy2(i,j);
    end
end

case 'Spline-based'  
    % y-horizontal derivative in space domain.
    [finalhdy2,Gyz] = Gzy_Gyz_dta_space( G.dta0,G.n1 );
end
%==============================================================================
downward=G.name(1:length(G.name)-4);

if n==1
   ord=([num2str(n) 'st order ']); 
elseif n==2
    ord=([num2str(n) 'nd order ']);
elseif n==3
    ord=([num2str(n) 'rd order ']);
else
    ord=([num2str(n) 'th order ']);
end

save([G.path ord 'Y-horizontal deivative ' downward '.txt'], 'finalhdy2', '-ASCII');

[G.xax,G.yax,G.hdy]=grid_data(finalhdy2,G.n);
orig_fig_g=figure('Name','Gravity potential','NumberTitle','off');
pcolor(G.xax,G.yax,G.hdy); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title({[ord 'Y-horizontal deivative'], downward});
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal.m');





%===================================================================
function Total_Horizontal_deivative( input1,input2)

% A function for calculating total horizontal derivative of gravity anomaly.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global G
format long
%==============================================================================
input1='Select the data text file';
Read_data(input1,G.n); 
%===========================================================
choice = questdlg('Select the derivative method:', ...
	'The derivative method', ...
	'FFT-based','Spline-based','FFT-based');
switch choice
case 'FFT-based'       



FFT_wavnum();
ffthdx=zeros(G.erowsm, G.ecolumnsn);% FFT of x-horizontal derivative values (expanded sized matrix)..
ffthdy=zeros(G.erowsm, G.ecolumnsn);% FFT of y-horizontal derivative values (expanded sized matrix)..
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            ffthdx(i,j)=(G.y(i,j)*(1i*(G.fkx(j))));
    end
end
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            ffthdy(i,j)=(G.y(i,j)*(1i*(G.fky(i))));
    end
end

%==============================================================================
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*ffthdx;
finalhdx=real(ifft2(filt));% Filtered x-horizontal derivative values (expanded sized matrix).
filt=(1.-flt).*ffthdy;
finalhdy=real(ifft2(filt));% Filtered y-horizontal derivative values (expanded sized matrix).

% Returning back to the original grid size
% finalhdx2 is x-horizontal derivative values (original sized matrix)..
% finalhdy2 is y-horizontal derivative values (original sized matrix)..
finalhdx2 = finalhdx(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);
finalhdy2 = finalhdy(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);

G.TotHd=zeros(G.rowsm,G.columnsn);% Total horizontal derivative values (original sized matrix)..
for i=1:G.rowsm
    for j=1:G.columnsn
        G.TotHd(i,j)=sqrt(finalhdx2(i,j)^2+finalhdy2(i,j)^2);
    end
end
FinTotHd=G.dta0;% Total horizontal derivative (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        FinTotHd(j+G.columnsn*(i-1),3)=G.TotHd(i,j);
    end
end

case 'Spline-based'  
    FinTotHd=G.dta0;% Total horizontal derivative in space domain.
    [finalhdx2,Gyz] = Gzy_Gyz_dta_space( G.dta0,G.n1 );
    [finalhdy2,Gxz] = Gzx_Gxz_dta_space( G.dta0,G.n1 );
    FinTotHd(:,3)=sqrt(finalhdx2(:,3).^2+finalhdy2(:,3).^2);
end
%==============================================================================
downward=G.name(1:length(G.name)-4);
%======================================================================

save([G.path 'Total horizontal deivative of the ' downward '.txt'], 'FinTotHd', '-ASCII');
[G.xax,G.yax,G.FinTotHd]=grid_data(FinTotHd,G.n);
orig_fig_g=figure('Name','Gravity potential','NumberTitle','off');
pcolor(G.xax,G.yax,G.FinTotHd); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title({'Total horizontal deivative', downward});
colormap(gca(orig_fig_g),colscale);
set(orig_fig_g,'WindowButtonMotionFcn',@cursorcoordinate);
set(get(cb,'ylabel'),'string','mGal.m');

%%

function Gravity_edge_detections(input1,input2)

% A function for delineating body's edges based on total horizontal 
% derivative and modulus of the gradient tensor.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Gxx,Gxy,Gxz,Gyx,Gyy,Gyz,Gzx,Gzy,Gzz are full gradient tensors of gravity potential.
% THDz is total horizontal derivative gravity field.
% M is  a modulus of the gravity gradient tensors.
% ED is edge detection anomaly.
%======================================================================
global G
format long
%======================================================================
choice = questdlg('Select the data type for edge detection:', ...
	'Data type to be processed', ...
	'Gravity potential anomaly','Vertical integration','Gravity potential anomaly');
switch choice
case 'Gravity potential anomaly'       
downward=Gravity_potential( input1,input2);

[Gzx,Gxz] = Gzx_Gxz_dta_space( G.dta0,G.n );
[Gzy,Gyz] = Gzy_Gyz_dta_space( G.dta0,G.n );
[Gxx,Gxy,Gyx,Gyy,Gzz] = Gxx_Gxy_Gyx_Gyy_Gzz_potn_space(G.ptnl,G.n);

case 'Vertical integration'
    downward=Vertical_integration( input1,input2 );
    choice2 = questdlg('Algorithm domain', ...
	'Select a domain', ...
	'Space domain','Wavenumber domain','Wavenumber domain');
 switch choice2
    case 'Space domain'
        
[Gzx,Gxz] = Gzx_Gxz_dta_space(G.dta0,G.n);
[Gzy,Gyz] = Gzy_Gyz_dta_space(G.dta0,G.n);
[Gxx,Gxy,Gyx,Gyy,Gzz] = Gxx_Gxy_Gyx_Gyy_Gzz_potn_space(G.Vint,G.n);

     case 'Wavenumber domain'
         [ Gxx,Gxy,Gxz,Gyx, Gzx] = Gxx_Gxy_Gxz_Gyx_Gzx();
         [Gyy,Gyz,Gzy,Gzz] = Gyy_Gyz_Gzy_Gzz();
 end
end

THDz=Gxx;
THDz(:,3)=sqrt(Gzx(:,3).^2+Gzy(:,3).^2);
M=sqrt(Gxx(:,3).^2+Gxy(:,3).^2+Gxz(:,3).^2+Gyx(:,3).^2+Gyy(:,3).^2+Gyz(:,3).^2+Gzx(:,3).^2+Gzy(:,3).^2+Gzz(:,3).^2);

ED=Gxx;
ED(:,3)=(THDz(:,3)./M).^2;
save([G.path 'Edge detection ' downward '.txt'], 'ED', '-ASCII');
[G.xax,G.yax,G.ED]=grid_data(ED,G.n);
orig_fig_g2=figure('Name','Edge detection based on gradient tensor','NumberTitle','off');
pcolor(G.xax,G.yax,G.ED); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); ylabel('y (m)','FontSize',12);
title({'Edge detection', downward});
colormap(gca(orig_fig_g2),colscale);
set(orig_fig_g2,'WindowButtonMotionFcn',@cursorcoordinate);

%%

function [Gyy,Gyz,Gzy,Gzz] = Gyy_Gyz_Gzy_Gzz()


% A function for computing some gradient tensor of a potental field in
% frequency domain.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
global G
format long
%=======================================================================

fftdy=zeros(G.erowsm, G.ecolumnsn);% FFT of y-horizontal derivative of vertically 
% integrated gravity values (expanded sized matrix)..
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdy(i,j)=(G.vintg(i,j)*(1i*(G.fky(i))));
    end
end

%==============================================================================
fftdyy=zeros(G.erowsm, G.ecolumnsn);% FFT of yy-derivative of vertically 
% integrated gravity values (expanded sized matrix)..
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdyy(i,j)=(fftdy(i,j)*(1i*(G.fky(i))));
    end
end
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1-flt).*fftdyy;
finaldyy=real(ifft2(filt));% Filtered yy-derivative of vertically integrated gravity (expanded sized matrix).


% Returning back to the original matrix size
% finaldyy2 is yy-derivative of vertically integrated gravity values (original sized matrix)..
finaldyy2 = finaldyy(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);


Gyy=G.dta0;% yy-derivative of vertically integrated gravity (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        Gyy(j+G.columnsn*(i-1),3)=finaldyy2(i,j);
    end
end


%=============================================================================

fftdyz=zeros(G.erowsm, G.ecolumnsn);% FFT of yz-derivative of vertically 
% integrated gravity values (expanded sized matrix)..
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdyz(i,j)=(fftdy(i,j)*(sqrt(G.fkx(j)^2+G.fky(i)^2)));
    end
end
filt=(1-flt).*fftdyz;
finaldyz=real(ifft2(filt));% Filtered yz-derivative of vertically integrated gravity (expanded sized matrix).

% Returning back to the original matrix size
% finaldyz2 is yz-derivative of vertically integrated gravity values (original sized matrix)..
finaldyz2 = finaldyz(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);


Gyz=G.dta0;% yz-derivative of vertically integrated gravity (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        Gyz(j+G.columnsn*(i-1),3)=finaldyz2(i,j);
    end
end

Gzy=Gyz;% zy-derivative of vertically integrated gravity (values+locations).


%=============================================================================
fftdzz=zeros(G.erowsm, G.ecolumnsn);% FFT of zz-derivative of vertically 
% integrated gravity values (expanded sized matrix)..
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdzz(i,j)=(G.vintg(i,j)*((G.fkx(j)^2+G.fky(i)^2)));
    end
end
filt=(1-flt).*fftdzz;
finaldzz=real(ifft2(filt));% Filtered zz-derivative of vertically integrated gravity (expanded sized matrix).


% Returning back to the original matrix size
% finaldzz2 is zz-derivative of vertically integrated gravity values (original sized matrix)..
finaldzz2 = finaldzz(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);


Gzz=G.dta0;% zz-derivative of vertically integrated gravity (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        Gzz(j+G.columnsn*(i-1),3)=finaldzz2(i,j);
    end
end


%%

function [ Gxx,Gxy,Gxz,Gyx, Gzx] = Gxx_Gxy_Gxz_Gyx_Gzx()

% A function for computing some gradient tensor of a potental field in
% frequency domain.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%=======================================================================
global G
format long
%=======================================================================

fftdx=zeros(G.erowsm, G.ecolumnsn);% FFT of x-horizontal derivative of vertically 
% integrated gravity values (expanded sized matrix).
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdx(i,j)=(G.vintg(i,j)*(1i*(G.fkx(j))));
    end
end

%==============================================================================
fftdxx=zeros(G.erowsm, G.ecolumnsn);% FFT of xx-derivative of vertically 
% integrated gravity values (expanded sized matrix).
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdxx(i,j)=(fftdx(i,j)*(1i*(G.fkx(j))));
    end
end
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*fftdxx;
finaldxx=real(ifft2(filt));% Filtered xx-derivative of vertically integrated gravity (expanded sized matrix).


% Returning back to the original matrix size
% finaldxx2 is xx-derivative of vertically integrated gravity values (original sized matrix).
finaldxx2 = finaldxx(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);


Gxx=G.dta0;% xx-derivative of vertically integrated gravity (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        Gxx(j+G.columnsn*(i-1),3)=finaldxx2(i,j);
    end
end

%=============================================================================

fftdxy=zeros(G.erowsm, G.ecolumnsn);% FFT of xy-derivative of vertically 
% integrated gravity values (expanded sized matrix).
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdxy(i,j)=(fftdx(i,j)*(1i*(G.fky(i))));
    end
end
filt=(1-flt).*fftdxy;
finaldxy=real(ifft2(filt));% Filtered xy-derivative of vertically integrated gravity (expanded sized matrix).

% Returning back to the original matrix size
% finaldxy2 is xy-derivative of vertically integrated gravity values (original sized matrix).
finaldxy2 = finaldxy(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);


Gxy=G.dta0;% xy-derivative of vertically integrated gravity (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        Gxy(j+G.columnsn*(i-1),3)=finaldxy2(i,j);
    end
end

Gyx=Gxy;% yx-derivative of vertically integrated gravity (values+locations).

%=============================================================================
fftdxz=zeros(G.erowsm, G.ecolumnsn);% FFT of xz-derivative of vertically 
% integrated gravity values (expanded sized matrix).
for i=1:G.erowsm 
    for j=1:G.ecolumnsn
            fftdxz(i,j)=(fftdx(i,j)*(sqrt(G.fkx(j)^2+G.fky(i)^2)));
    end
end
filt=(1.-flt).*fftdxz;
finaldxz=real(ifft2(filt));% Filtered xz-derivative of vertically integrated gravity (expanded sized matrix).

% Returning back to the original matrix size
% finaldxz2 is xz-derivative of vertically integrated gravity values (original sized matrix).
finaldxz2 = finaldxz(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);

Gxz=G.dta0;% xz-derivative of vertically integrated gravity (values+locations).
for i=1:G.rowsm
    for j=1:G.columnsn
        Gxz(j+G.columnsn*(i-1),3)=finaldxz2(i,j);
    end
end

Gzx=Gxz;% zx-derivative of vertically integrated gravity (values+locations).

%%


function [Gzx,Gxz] = Gzx_Gxz_dta_space( dta,n1)

% A function for computing some gradient tensor of a potental field in
% space domain (spline-based).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
global G
format long
%=======================================================================
% dta is gravity field data.
% n1 is number of the required data point at each horizontal axis (x- and
% y-axis).

%===========================================================================
m=G.rowsm;% Number of data points in y-direction.
n=G.columnsn;% Number of data points in x-direction.
[nwx,nwy,qz]=grid_data(dta,n1);

sp=spapi({5,5},{nwx,nwy},qz'); 
dspx=fnder(sp,[1,0]);
H_Dervx=(fnval(dspx,{nwx,nwy}))';% x-horizontal derivative of gravity field (values).
G.dta1=H_Dervx;
FFT_wavnum();
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*G.y;
H_Dervx=real(ifft2(filt));% Filtered x-horizontal derivative(expanded sized matrix).

% Returning back to the original matrix size
% H_Dervx2 is x-horizontal values (original sized matrix).
H_Dervx2 = H_Dervx(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);

Gzx=dta;% x-horizontal derivative of gravity field (values+locations).
for i = 1:m
    for j = 1:n
    Gzx(j+n*(i-1),3)=H_Dervx2(i,j);  
    end
end
Gxz=Gzx;% xz-derivative of gravity potential (values+locations).

%%

function [Gzy,Gyz] = Gzy_Gyz_dta_space( dta,n1 )

% A function for computing some gradient tensor of a potental field in
% space domain (spline-based).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
global G
format long
%=======================================================================

% dta is gravity field data.
% n1 is number of the required data point at each horizontal axis (x- and
% y-axis).

%===========================================================================
m=G.rowsm;% Number of data points in y-direction.
n=G.columnsn;% Number of data points in x-direction.
[nwx,nwy,qz]=grid_data(dta,n1);

sp=spapi({5,5},{nwx,nwy},qz'); 
dspy=fnder(sp,[0,1]);
H_Dervy=(fnval(dspy,{nwx,nwy}))';% y-horizontal derivative of gravity field (values).
G.dta1=H_Dervy;
FFT_wavnum();
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*G.y;
H_Dervy=real(ifft2(filt));% Filtered y-horizontal derivative(expanded sized matrix).

% Returning back to the original matrix size
% H_Dervy2 is y-horizontal values (original sized matrix).
H_Dervy2 = H_Dervy(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);

Gzy=dta;% y-horizontal derivative of gravity field (values+locations).
for i = 1:m
    for j = 1:n 
    Gzy(j+n*(i-1),3)=H_Dervy2(i,j); 
    end
end
Gyz=Gzy;% yz-derivative of gravity potential (values+locations).

%%

function [Gxx,Gxy,Gyx,Gyy,Gzz] = Gxx_Gxy_Gyx_Gyy_Gzz_potn_space(dta,n1)


% A function for computing some gradient tensor of a potental field in
% space domain (spline-based).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
global G
format long
%=======================================================================

% dta is gravity potential data.
% n1 is number of the required data point at each horizontal axis (x- and
% y-axis).

%===========================================================================
%
m=G.rowsm;% Number of data points in y-direction.
n=G.columnsn;% Number of data points in x-direction.
[nwx,nwy,qz]=grid_data(dta,n1);

sp=spapi({5,5},{nwx,nwy},qz'); 

dspxx=fnder(sp,[2,0]);
H_Dervxx=(fnval(dspxx,{nwx,nwy}))';% xx-derivative of gravity potential (values).
G.dta1=H_Dervxx;
FFT_wavnum();
cut=max(G.fkx)/2;
[x y]=meshgrid(G.fkx,G.fky);
flt=1./(1.+(cut./sqrt(x.^2+y.^2)).^(2*G.ord));
filt=(1.-flt).*G.y;
H_Dervxx1=real(ifft2(filt));% Filtered xx-derivative of gravity potential(expanded sized matrix).

% Returning back to the original matrix size
% H_Dervxx2 is xx-derivative of gravity potential values (original sized matrix).
H_Dervxx2 = H_Dervxx1(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);

dspyy=fnder(sp,[0,2]);
H_Dervyy=(fnval(dspyy,{nwx,nwy}))';% yy-derivative of gravity potential (values).
G.dta1=H_Dervyy;
FFT_wavnum();
filt=(1-flt).*G.y;
H_Dervyy=real(ifft2(filt));% Filtered yy-derivative of gravity potential(expanded sized matrix).

% Returning back to the original matrix size
% H_Dervyy2 is yy-derivative of gravity potential values (original sized matrix).
H_Dervyy2 = H_Dervyy(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);

dspxy=fnder(sp,[1,1]);
H_Dervxy=(fnval(dspxy,{nwx,nwy}))';% xy-derivative of gravity potential (values).
G.dta1=H_Dervxy;
FFT_wavnum();
filt=(1-flt).*G.y;
H_Dervxy1=real(ifft2(filt));% Filtered xy-derivative of gravity potential(expanded sized matrix).

% Returning back to the original matrix size
% H_Dervxy2 is xy-derivative of gravity potential values (original sized matrix).
H_Dervxy2 = H_Dervxy1(G.numextrRows+1:G.erowsm-G.numextrRows,G.numextrCols+1:G.ecolumnsn-G.numextrCols);

Gxx=dta;% xx-derivative of gravity potential (values+locations).
Gxy=dta;% xy-derivative of gravity potential (values+locations).
Gyy=dta;% yy-derivative of gravity potential (values+locations).
Gzz=dta;% zz-derivative of gravity potential (values+locations).
for i = 1:m
    for j = 1:n
    Gxx(j+n*(i-1),3)=H_Dervxx2(i,j); 
    Gxy(j+n*(i-1),3)=H_Dervxy2(i,j);
    Gyy(j+n*(i-1),3)=H_Dervyy2(i,j); 
    end
end
Gzz(:,3)=-(Gxx(:,3)+Gyy(:,3));
Gyx=Gxy;% yx-derivative of gravity potential (values+locations).



%%

function sphere_gravity_effect(input1,input2 )

% A function for computing gravity effect of spheres.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
global G
format long
%=======================================================================

[G.name,G.path] = uigetfile('*.txt','Select your model text file');
cdir=pwd;cd (G.path)
model = dlmread(G.name);
cd (cdir)

[N,colm]=size(model);% N is a number of prisms.

X=zeros(N,7); 
for i=1:N
X(i,1)=model(i,1);% Sphere radius (m).
X(i,2)=model(i,2);% Sphere x-coordinate (m). 
X(i,3)=model(i,3);% Sphere y-coordinate (m).
X(i,4)=abs(model(i,4));% Sphere z-coordinate (m).
X(i,5)=model(i,5);% Sphere density contrast (kg/m^3);
end


m=model(1,6);% Number of data points along x-axis.
n=model(1,7);% Number of data points along y-axis.
sx=model(1,8);% Spacing along x-axis (m).
sy=model(1,9);% Spacing along y-axis (m). 
stx=model(1,10);
sty=model(1,11);
y=sty;
M=colm-11;% Number of observation levels.
level=zeros(M,1);
cont=12;
for i=1:M
    level(i)=model(1,cont);
    cont=cont+1;
end
dta=zeros(m*n,4);% Gravity field at different observation points caused by the model. 


G1 =6.67E-11;% Universal gravitational constant.

for i=1:m
    x=stx;
    for j=1:n
        dta(j+n*(i-1),1)=x;x=x+sx;
        dta(j+n*(i-1),2)=y;
    end
    y=y+sy;
end
a1=sx*(n-1);a2=sy*(m-1);
for k=1:M
    dta(:,3)=0;
for ii=1:N
    g=1E5*G1*4*pi*X(ii,1)^3/3;
for i=1:m
    for j=1:n
        dta(j+n*(i-1),3)=dta(j+n*(i-1),3)+X(ii,5)*g*gravity_effect_of_sphere( dta(j+n*(i-1),1),dta(j+n*(i-1),2),level(k),X(ii,2),X(ii,3),X(ii,4) );
        dta(j+n*(i-1),4)=level(k);
    end
end
end

save([G.path  'Gravity effect of ' num2str(N) ' spheres - observation plane ' num2str(level(k)) ' m.txt'],'dta','-ascii');


[G.xax,G.yax,G.dta1,G.dta2]=grid_data(dta,G.n);
G.dta0=zeros(G.m11,4);
for i=1:G.rowsm
    for j=1:G.columnsn
        G.dta0(j+G.columnsn*(i-1),1)=G.xax(j);
        G.dta0(j+G.columnsn*(i-1),2)=G.yax(i);
        G.dta0(j+G.columnsn*(i-1),3)=G.dta1(i,j);
        G.dta0(j+G.columnsn*(i-1),4)=G.dta2(i,j);
    end
end

Local_max_min_gravity_magnetic_refined();

% Figures
colormap(gca(figure),colscale);
subplot(2,2,1);hold on;
grid on

xlim([stx,a1+stx]);
ylim([sty,a1+sty]);

pcolor(G.xax,G.yax,G.dta1); 
cb1=colorbar; 
set(get(cb1,'zlabel'),'string','mGal');
xlabel ('x (m)','FontSize',12); 
ylabel('y (m)','FontSize',12);
zlabel('Gravity (mGal)','FontSize',12);
title({['Gravity effect of '  num2str(N) ' spheres'],['observation plane = ' num2str(-level(k)) ' m']});
surface(G.xax,G.yax,G.dta1);shading interp;
hold off;
view(37,30);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,2);hold on;
xlim([stx,a1+stx]);
ylim([sty,a1+sty]);
pcolor(G.xax,G.yax,G.dta1); cb=colorbar; shading interp;
xlabel ('x (m)','FontSize',12); 
ylabel('y (m)','FontSize',12);
title({['Gravity effect of '  num2str(N) ' spheres'],['observation plane = ' num2str(-level(k)) ' m']});
set(get(cb,'ylabel'),'string','mGal');hold off;
%%%%%%%%%%%%%%%%
subplot(2,2,3);

daspect([1 1 1])
hold on
a3=max(X(:,1))+max(X(:,4));
cube_plot(a1,a2,a3,stx,sty,0,'none',[0 0 0]);
plot_sphere( N,X );
% set axes limits
xlim([stx,a1+stx]);
ylim([sty,a2+sty]);
zlim([(-a3),0]);
grid on
% Set the lable and the font size
xlabel('x (m)','FontSize',12);
ylabel('y (m)','FontSize',12);
zlabel('Depth (m)','FontSize',12);
title({'Synthetic model of ',[ num2str(N) ' spheres']});hold off
view(37,30);
%====================================================
subplot(2,2,4);hold on;
xlim([stx,a1+stx]);
ylim([sty,a2+sty]);
xlabel ('x (m)','FontSize',12); 
ylabel('y (m)','FontSize',12);
title('Equivalent source locations');
shading interp;


for i=1:G.count
    text(G.MDL(i,1),G.MDL(i,2),'.' ,'FontSize',10,'FontWeight','Bold');
end

set(get(cb,'ylabel'),'string','mGal');hold off;
end
%%

function  g  = gravity_effect_of_sphere( x,y,z,X,Y,Z )

% A function for calculating gravity effect of a sphere.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
format long
%=======================================================================
% x is observation point x-coordinate.
% y is observation point y-coordinate.
% z is observation point z-coordinate (positive above and negative below zero level).
% X is sphere center x-coordinate.
% Y is sphere center y-coordinate.
% Z is sphere center z-coordinate (the program make it positive).
% g is a factor multipied later by universal gravitational constant and the
% sphere density to get gravity field of the sphere.
	
	g = (Z+z)/(((X - x)^2 + (Y - y)^2 + (Z+z)^2)^(3/2));

%%

function  plot_sphere( N,X )

% A function for plotting sphere in 3D space.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
format long
%=======================================================================


[xs ys zs]=sphere;

for j=1:N
    surf(xs*X(j,1)+X(j,2),ys*X(j,1)+X(j,3),zs*X(j,1)-X(j,4));
end

grid off;


%%

function prism_gravity_effect(input1,input2 )

% A function for computing gravity effect of rectangular prisms.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
global G
format long
%=======================================================================

[name,G.path] = uigetfile('*.txt','Select your model text file');
cdir=pwd;cd (G.path)
model = dlmread(name);
cd (cdir)

[N,colm]=size(model);% N is a number of prisms.

X=zeros(N,7); 
for i=1:N
X(i,1)=model(i,1); % Prism x-coordinate (m). 
X(i,4)=model(i,2);% Prism width in x-direction.
X(i,2)=model(i,3);% Prism y-coordinate (m).
X(i,5)=model(i,4);% Prism width in y-direction.
X(i,3)=abs(model(i,5));% Prism z-coordinate (m).
X(i,6)=model(i,6);% Prism thickness.
X(i,7)=model(i,7);% Prism density contrast (kg/m^3);
end


m=model(1,8);% Number of data points along x-axis.
n=model(1,9);% Number of data points along y-axis.
sx=model(1,10);% Spacing along x-axis (m).
sy=model(1,11);% Spacing along y-axis (m). 
stx=model(1,12);% Beginning of the model at x-axis.
sty=model(1,13);% Beginning of the model at y-axis.
y=sty;
M=colm-13;% Number of observation levels.
level=zeros(M,1);
cont=14;
for i=1:M
    level(i)=model(1,cont);
    cont=cont+1;
end
dta=zeros(m*n,4);% Gravity field at different observation points caused by the model.


G1 =6.67E-11;% Universal gravitational constant.
g=1E5*G1; % constant.
for i=1:m
    x=stx;
    for j=1:n
        dta(j+n*(i-1),1)=x;x=x+sx;
        dta(j+n*(i-1),2)=y;
    end
    y=y+sy;
end

a1=sx*(n-1);a2=sy*(m-1);
for k=1:M
    dta(:,3)=0;
for ii=1:N
for i=1:m
    for j=1:n
        dta(j+n*(i-1),3)=dta(j+n*(i-1),3)+X(ii,7)*g*gravity_effect_of_prism( dta(j+n*(i-1),1),dta(j+n*(i-1),2),level(k),X(ii,1),X(ii,2),X(ii,3),X(ii,4),X(ii,5),X(ii,6) );
        dta(j+n*(i-1),4)=level(k);
    end
end
end

save([G.path  ['Gravity effect of '  num2str(N) ' prisms - observation plane ' num2str(level(k)) ' m.txt']],'dta','-ascii');


[G.xax,G.yax,G.dta1,G.dta2]=grid_data(dta,G.n);
G.dta0=zeros(G.m11,4);
for i=1:G.rowsm
    for j=1:G.columnsn
        G.dta0(j+G.columnsn*(i-1),1)=G.xax(j);
        G.dta0(j+G.columnsn*(i-1),2)=G.yax(i);
        G.dta0(j+G.columnsn*(i-1),3)=G.dta1(i,j);
        G.dta0(j+G.columnsn*(i-1),4)=G.dta2(i,j);
    end
end

Local_max_min_gravity_magnetic_refined();
% figure
colormap(gca(figure),colscale);
subplot(2,2,1);hold on;
grid on

xlim([stx,a1+stx]);
ylim([sty,a2+sty]);

pcolor(G.xax,G.yax,G.dta1); 
cb1=colorbar; 
set(get(cb1,'zlabel'),'string','mGal');
xlabel ('x (m)','FontSize',12); 
ylabel('y (m)','FontSize',12);
zlabel('Gravity (mGal)','FontSize',12);
title({['Gravity effect of '  num2str(N) ' prisms'],['observation plane = ' num2str(-level(k)) ' m']});
surf(G.xax,G.yax,G.dta1);shading interp;
hold off;
view(37,30);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,2);hold on;
xlim([stx,a1+stx]);
ylim([sty,a2+sty]);

pcolor(G.xax,G.yax,G.dta1); cb=colorbar; 
xlabel ('x (m)','FontSize',12); 
ylabel('y (m)','FontSize',12);
title({['Gravity effect of '  num2str(N) ' prisms'],['observation plane = ' num2str(-level(k)) ' m']});
shading interp;

for i=1:N
    if X(i,4)<a1&&X(i,5)<a2
        plane_plot(X(i,4),X(i,5),X(i,1),X(i,2),'none',[0 0 0] );
        text(X(i,1)+X(i,4)/10,X(i,2)+X(i,5)*5/6,['(' num2str(i) ')'],'FontSize',10,'FontWeight','Bold');
    end
end
set(get(cb,'ylabel'),'string','mGal');hold off;
%%%%%%%%%%%%%%%%
subplot(2,2,3);

daspect([1 1 1])
hold on
a3=max(X(:,3))+max(X(:,6));

cube_plot(a1,a2,a3,stx,sty,0,'none',[0 0 0]);

clr1=[1 0 1];

for ii=1:N
    if X(ii,7)>0
        if X(ii,4)<a1&&X(ii,5)<a2
            cube_plot(X(ii,4),X(ii,5),X(ii,6),X(ii,1),X(ii,2),-X(ii,3),[1 0 0],[0 0 0] );
        elseif X(ii,4)>=a1&&X(ii,3)<max(X(:,3))||X(ii,5)>=a2&&X(ii,3)<max(X(:,3))
            cube_plot( a1,a2,X(ii,6),dta(1,1),dta(1,2),-X(ii,3),'none',[0 0 0] );
        elseif X(ii,4)>=a1&&X(ii,3)==max(X(:,3))||X(ii,5)>=a2&&X(ii,3)==max(X(:,3))
            cube_plot(a1,a2,(a3-X(ii,3)),dta(1,1),dta(1,2),-X(ii,3),clr1,[0 0 0] );
        end
    elseif X(ii,7)<0
        if X(ii,4)<a1&&X(ii,5)<a2
            cube_plot( X(ii,4),X(ii,5),X(ii,6),X(ii,1),X(ii,2),-X(ii,3),[0 0 1],[0 0 0] );
        elseif X(ii,4)>=a1&&X(ii,3)<max(X(:,3))||X(ii,5)>=a2&&X(ii,3)<max(X(:,3))
            cube_plot( a1,a2,X(ii,6),dta(1,1),dta(1,2),-X(ii,3),'none',[0 0 0] );
        elseif X(ii,4)>=a1&&X(ii,3)==max(X(:,3))||X(ii,5)>=a2&&X(ii,3)==max(X(:,3))
            cube_plot( a1,a2,(a3-X(ii,3)),dta(1,1),dta(1,2),-X(ii,3),clr1,[0 0 0] );
        end
    end
    
end
% set axes limits
xlim([stx,a1+stx]);
ylim([sty,a2+sty]);
zlim([(-a3),0]);
grid on
% Set the lable and the font size
xlabel('x (m)','FontSize',12);
ylabel('y (m)','FontSize',12);
zlabel('Depth (m)','FontSize',12);
title({'Synthetic model of ',[ num2str(N) ' rectangular prisms']});hold off
view(37,30);

%==========================================================
subplot(2,2,4);hold on;
xlim([stx,a1+stx]);
ylim([sty,a2+sty]);
xlabel ('x (m)','FontSize',12); 
ylabel('y (m)','FontSize',12);
title('Equivalent source locations');
shading interp;

for i=1:N
    if X(i,4)<a1&&X(i,5)<a2
        plane_plot( X(i,4),X(i,5),X(i,1),X(i,2),'none',[0 0 0] );
        text(X(i,1)+X(i,4)/10,X(i,2)+X(i,5)*5/6,['(' num2str(i) ')'],'FontSize',10,'FontWeight','Bold');
    end
end
for i=1:G.count
    text(G.MDL(i,1),G.MDL(i,2),'.' ,'FontSize',10,'FontWeight','Bold');
end

set(get(cb,'ylabel'),'string','mGal');hold off;
end


%%

function  g  = gravity_effect_of_prism( x,y,z,X,Y,Z,sx,sy,t)

 
% A function for computing gravity effect of a rectangular prism.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: ABDU ELAZEEM OSMAN ADAM ALI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%=======================================================================
format long
%=======================================================================
% x is observation point x-coordinate.
% y is observation point y-coordinate.
% z is observation point z-coordinate (positive above and negative below zero level).
% X is prism starting x-coordinate.
% Y is prism starting y-coordinate.
% Z is prism starting z-coordinate (the program make it positive).
% X2 is prism ending x-coordinate.
% Y2 is prism ending y-coordinate.
% Z2 is prism ending z-coordinate (the program make it positive).
% g is a factor multipied later by universal gravitational constant and the
% sphere density to get gravity field of the sphere.


X2 = (X + sx) - x; Y2 = (Y + sy) - y ; Z2 = (Z + t)+z;
	X1 = X - x; Y1 = Y - y; Z1=Z+z;
	a1 = sqrt(X2^2 + Y2^2 + (Z2^2));
	a2 = sqrt(X1^2 + Y2^2 + Z2^2);
	a3 = sqrt(X2^2 + Y1^2 + (Z2^2));
	a4 = sqrt(X1^2 + Y1^2 + (Z2^2));
	a5 = sqrt(X2^2 + Y2^2 + (Z1^2));
	a6 = sqrt(X1^2 + Y2^2 + (Z1^2));
	a7 = sqrt(X2^2 + Y1^2 + (Z1^2));
	a8 = sqrt(X1^2 + Y1^2 + (Z1^2));
	
	g = -(X2*log(Y2 + a1) + Y2*log(X2 + a1) - Z2*atan((X2*Y2) / (Z2*a1)) - X1*log(Y2 + a2) - Y2*log(X1 + a2) + Z2*atan((X1*Y2) / (Z2*a2))...
		- X2*log(Y1 + a3) - Y1*log(X2 + a3) + Z2*atan((X2*Y1) / (Z2*a3)) + X1*log(Y1 + a4) + Y1*log(X1 + a4) - Z2*atan((X1*Y1) / (Z2*a4))...
		- X2*log(Y2 + a5) - Y2*log(X2 + a5) + Z1*atan((X2*Y2) / (Z1*a5)) + X1*log(Y2 + a6) + Y2*log(X1 + a6) - Z1*atan((X1*Y2) / (Z1*a6))...
		+ X2*log(Y1 + a7) + Y1*log(X2 + a7) - Z1*atan((X2*Y1) / (Z1*a7)) - X1*log(Y1 + a8) - Y1*log(X1 + a8) + Z1*atan((X1*Y1) / (Z1*a8)));
		
        
        
%%


function cube_plot( X,Y,Z,xmin,ymin,zmin,color1,color2 )

% A function for plotting a rectangular prism.

%=======================================================================
format long
%=======================================================================

% CUBE_PLOT plots a cube with dimension of X, Y, Z.
%
% INPUTS:
% origin = set origin point for the cube in the form of [x,y,z].
% X      = cube length along x direction.
% Y      = cube length along y direction.
% Z      = cube length along z direction.
xmax=xmin+X;ymax=ymin+Y;zmax=zmin-Z;
% Define the vertexes of the unit cubic
ver = [xmin ymin zmin;
    xmax ymin zmin;
    xmax ymax zmin;
    xmin ymax zmin;
    xmin ymin zmax;
    xmax ymin zmax;
    xmax ymax zmax;
    xmin ymax zmax];
%  Define the faces of the unit cubic
fac = [1 2 3 4;
    4 8 7 3;
    3 2 6 7;
    7 8 5 6;
    6 2 1 5;
    5 8 4 1];
% cube = [ver(:,1)+origin(1),ver(:,2)+origin(2),ver(:,3)+origin(3)];
cube = [ver(:,1),ver(:,2),ver(:,3)];
patch('Faces',fac,'Vertices',cube,'FaceColor',color1,'EdgeColor',color2);

%%

function plane_plot( X,Y,xmin,ymin,color1,color2 )

% A function for plotting a plane surface.

%=======================================================================
format long
%=======================================================================

% CUBE_PLOT plots a cube with dimension of X, Y.
%
% INPUTS:
% origin = set origin point for the cube in the form of [x,y,z].
% X      = cube length along x direction.
% Y      = cube length along y direction.
xmax=xmin+X;ymax=ymin+Y;
% Define the vertexes of the unit cubic
ver = [xmin ymin;
    xmax ymin;
    xmax ymax;
    xmin ymax];
%  Define the faces of the unit cubic
fac = [1 2 3 4];
plane = [ver(:,1),ver(:,2)];
patch('Faces',fac,'Vertices',plane,'FaceColor',color1,'EdgeColor',color2);


%%


function about(src,eventdata)
% ABOUT
msgbox({'GRAVITY ANALYSIS, 2018','China University of Petroleum (East China), China','Red Sea University, Sudan','University of Khatoum, Sudan','Authors: A. O. Adam-Ali, Z. Liu, Y. Bai,','A. G. Farwa, A. S. Ahmed, G. Peng','azama77750@yahoo.com'},'About')


%==================== Set of functions written by: MathWorks Support Team ===========
% 
% (https://cn.mathworks.com/matlabcentral/answers/uploaded_files/1727/newid.m)
% for modifying the "inputdlg" function to make pressing the "Enter"
% key mimic the behavior of clicking the "OK" button.

function Answer=inputdlg(Prompt, Title, NumLines, DefAns, Resize)
% written by: https://cn.mathworks.com/matlabcentral/answers/uploaded_files/1727/newid.m
%INPUTDLG Input dialog box.
%  ANSWER = INPUTDLG(PROMPT) creates a modal dialog box that returns user
%  input for multiple prompts in the cell array ANSWER. PROMPT is a cell
%  array containing the PROMPT strings.
%
%  INPUTDLG uses UIWAIT to suspend execution until the user responds.
%
%  ANSWER = INPUTDLG(PROMPT,NAME) specifies the title for the dialog.
%
%  ANSWER = INPUTDLG(PROMPT,NAME,NUMLINES) specifies the number of lines for
%  each answer in NUMLINES. NUMLINES may be a constant value or a column
%  vector having one element per PROMPT that specifies how many lines per
%  input field. NUMLINES may also be a matrix where the first column
%  specifies how many rows for the input field and the second column
%  specifies how many columns wide the input field should be.
%
%  ANSWER = INPUTDLG(PROMPT,NAME,NUMLINES,DEFAULTANSWER) specifies the
%  default answer to display for each PROMPT. DEFAULTANSWER must contain
%  the same number of elements as PROMPT and must be a cell array of
%  strings.
%
%  ANSWER = INPUTDLG(PROMPT,NAME,NUMLINES,DEFAULTANSWER,OPTIONS) specifies
%  additional options. If OPTIONS is the string 'on', the dialog is made
%  resizable. If OPTIONS is a structure, the fields Resize, WindowStyle, and
%  Interpreter are recognized. Resize can be either 'on' or
%  'off'. WindowStyle can be either 'normal' or 'modal'. Interpreter can be
%  either 'none' or 'tex'. If Interpreter is 'tex', the prompt strings are
%  rendered using LaTeX.
%
%  Examples:
%
%  prompt={'Enter the matrix size for x^2:','Enter the colormap name:'};
%  name='Input for Peaks function';
%  numlines=1;
%  defaultanswer={'20','hsv'};
%
%  answer=inputdlg(prompt,name,numlines,defaultanswer);
%
%  options.Resize='on';
%  options.WindowStyle='normal';
%  options.Interpreter='tex';
%
%  answer=inputdlg(prompt,name,numlines,defaultanswer,options);
%
%  See also DIALOG, ERRORDLG, HELPDLG, LISTDLG, MSGBOX,
%    QUESTDLG, TEXTWRAP, UIWAIT, WARNDLG .

%  Copyright 1994-2005 The MathWorks, Inc.
%  $Revision: 1.58.4.11 $

%%%%%%%%%%%%%%%%%%%%
%%% Nargin Check %%%
%%%%%%%%%%%%%%%%%%%%
error(nargchk(0,5,nargin));
error(nargoutchk(0,1,nargout));

%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Handle Input Args %%%
%%%%%%%%%%%%%%%%%%%%%%%%%
if nargin<1
    Prompt='Input:';
end
if ~iscell(Prompt)
    Prompt={Prompt};
end
NumQuest=numel(Prompt);


if nargin<2,
    Title=' ';
end

if nargin<3
    NumLines=1;
end

if nargin<4 
    DefAns=cell(NumQuest,1);
    for lp=1:NumQuest
        DefAns{lp}='';
    end
end

if nargin<5
    Resize = 'off';
end
WindowStyle='modal';
Interpreter='none';

Options = struct([]); %#ok
if nargin==5 && isstruct(Resize)
    Options = Resize;
    Resize  = 'off';
    if isfield(Options,'Resize'),      Resize=Options.Resize;           end
    if isfield(Options,'WindowStyle'), WindowStyle=Options.WindowStyle; end
    if isfield(Options,'Interpreter'), Interpreter=Options.Interpreter; end
end

[rw,cl]=size(NumLines);
OneVect = ones(NumQuest,1);
if (rw == 1 & cl == 2) %#ok Handle []
    NumLines=NumLines(OneVect,:);
elseif (rw == 1 & cl == 1) %#ok
    NumLines=NumLines(OneVect);
elseif (rw == 1 & cl == NumQuest) %#ok
    NumLines = NumLines';
elseif (rw ~= NumQuest | cl > 2) %#ok
    error('MATLAB:inputdlg:IncorrectSize', 'NumLines size is incorrect.')
end

if ~iscell(DefAns),
    error('MATLAB:inputdlg:InvalidDefaultAnswer', 'Default Answer must be a cell array of strings.');
end

%%%%%%%%%%%%%%%%%%%%%%%
%%% Create InputFig %%%
%%%%%%%%%%%%%%%%%%%%%%%
FigWidth=175;
FigHeight=100;
FigPos(3:4)=[FigWidth FigHeight];  %#ok
FigColor=get(0,'DefaultUicontrolBackgroundcolor');

InputFig=dialog(                     ...
    'Visible'          ,'off'      , ...
    'KeyPressFcn'      ,@doFigureKeyPress, ...
    'Name'             ,Title      , ...
    'Pointer'          ,'arrow'    , ...
    'Units'            ,'pixels'   , ...
    'UserData'         ,'Cancel'   , ...
    'Tag'              ,Title      , ...
    'HandleVisibility' ,'callback' , ...
    'Color'            ,FigColor   , ...
    'NextPlot'         ,'add'      , ...
    'WindowStyle'      ,WindowStyle, ...
    'DoubleBuffer'     ,'on'       , ...
    'Resize'           ,Resize       ...
    );


%%%%%%%%%%%%%%%%%%%%%
%%% Set Positions %%%
%%%%%%%%%%%%%%%%%%%%%
DefOffset    = 5;
DefBtnWidth  = 53;
DefBtnHeight = 23;

TextInfo.Units              = 'pixels'   ;   
TextInfo.FontSize           = get(0,'FactoryUIControlFontSize');
TextInfo.FontWeight         = get(InputFig,'DefaultTextFontWeight');
TextInfo.HorizontalAlignment= 'left'     ;
TextInfo.HandleVisibility   = 'callback' ;

StInfo=TextInfo;
StInfo.Style              = 'text'  ;
StInfo.BackgroundColor    = FigColor;


EdInfo=StInfo;
EdInfo.FontWeight      = get(InputFig,'DefaultUicontrolFontWeight');
EdInfo.Style           = 'edit';
EdInfo.BackgroundColor = 'white';

BtnInfo=StInfo;
BtnInfo.FontWeight          = get(InputFig,'DefaultUicontrolFontWeight');
BtnInfo.Style               = 'pushbutton';
BtnInfo.HorizontalAlignment = 'center';

% Add VerticalAlignment here as it is not applicable to the above.
TextInfo.VerticalAlignment  = 'bottom';
TextInfo.Color              = get(0,'FactoryUIControlForegroundColor');


% adjust button height and width
btnMargin=1.4;
ExtControl=uicontrol(InputFig   ,BtnInfo     , ...
                     'String'   ,'OK'        , ...
                     'Visible'  ,'off'         ...
                     );

% BtnYOffset  = DefOffset;
BtnExtent = get(ExtControl,'Extent');
BtnWidth  = max(DefBtnWidth,BtnExtent(3)+8);
BtnHeight = max(DefBtnHeight,BtnExtent(4)*btnMargin);
delete(ExtControl);

% Determine # of lines for all Prompts
TxtWidth=FigWidth-2*DefOffset;
ExtControl=uicontrol(InputFig   ,StInfo     , ...
                     'String'   ,''         , ...
                     'Position' ,[ DefOffset DefOffset 0.96*TxtWidth BtnHeight ] , ...
                     'Visible'  ,'off'        ...
                     );

WrapQuest=cell(NumQuest,1);
QuestPos=zeros(NumQuest,4);

for ExtLp=1:NumQuest
    if size(NumLines,2)==2
        [WrapQuest{ExtLp},QuestPos(ExtLp,1:4)]= ...
            textwrap(ExtControl,Prompt(ExtLp),NumLines(ExtLp,2));
    else
        [WrapQuest{ExtLp},QuestPos(ExtLp,1:4)]= ...
            textwrap(ExtControl,Prompt(ExtLp),80);
    end
end % for ExtLp

delete(ExtControl);
QuestWidth =QuestPos(:,3);
QuestHeight=QuestPos(:,4);

TxtHeight=QuestHeight(1)/size(WrapQuest{1,1},1);
EditHeight=TxtHeight*NumLines(:,1);
EditHeight(NumLines(:,1)==1)=EditHeight(NumLines(:,1)==1)+4;

FigHeight=(NumQuest+2)*DefOffset    + ...
          BtnHeight+sum(EditHeight) + ...
          sum(QuestHeight);

TxtXOffset=DefOffset;

QuestYOffset=zeros(NumQuest,1);
EditYOffset=zeros(NumQuest,1);
QuestYOffset(1)=FigHeight-DefOffset-QuestHeight(1);
EditYOffset(1)=QuestYOffset(1)-EditHeight(1);

for YOffLp=2:NumQuest,
    QuestYOffset(YOffLp)=EditYOffset(YOffLp-1)-QuestHeight(YOffLp)-DefOffset;
    EditYOffset(YOffLp)=QuestYOffset(YOffLp)-EditHeight(YOffLp);
end % for YOffLp

QuestHandle=[]; 
EditHandle=[];

AxesHandle=axes('Parent',InputFig,'Position',[0 0 1 1],'Visible','off');

inputWidthSpecified = false;

for lp=1:NumQuest,
    if ~ischar(DefAns{lp}),
        delete(InputFig);
        %error('Default Answer must be a cell array of strings.');
        error('MATLAB:inputdlg:InvalidInput', 'Default Answer must be a cell array of strings.');
    end

    EditHandle(lp)=uicontrol(InputFig    , ...
                             EdInfo      , ...
                             'Max'        ,NumLines(lp,1)       , ...
                             'Position'   ,[ TxtXOffset EditYOffset(lp) TxtWidth EditHeight(lp) ], ...
                             'String'     ,DefAns{lp}           , ...
                             'Tag'        ,'Edit',                ...
                              'Callback' ,@doEnter);
                             

    QuestHandle(lp)=text('Parent'     ,AxesHandle, ...
                         TextInfo     , ...
                         'Position'   ,[ TxtXOffset QuestYOffset(lp)], ...
                         'String'     ,WrapQuest{lp}                 , ...
                         'Interpreter',Interpreter                   , ...
                         'Tag'        ,'Quest'                         ...
                         );

    MinWidth = max(QuestWidth(:));
    if (size(NumLines,2) == 2)
        % input field width has been specified.
        inputWidthSpecified = true;
        EditWidth = setcolumnwidth(EditHandle(lp), NumLines(lp,1), NumLines(lp,2));
        MinWidth = max(MinWidth, EditWidth);
    end
    FigWidth=max(FigWidth, MinWidth+2*DefOffset);

end % for lp

% fig width may have changed, update the edit fields if they dont have user specified widths.
if ~inputWidthSpecified
    TxtWidth=FigWidth-2*DefOffset;
    for lp=1:NumQuest
        set(EditHandle(lp), 'Position', [TxtXOffset EditYOffset(lp) TxtWidth EditHeight(lp)]);
    end
end

FigPos=get(InputFig,'Position');

FigWidth=max(FigWidth,2*(BtnWidth+DefOffset)+DefOffset);
FigPos(1)=0;
FigPos(2)=0;
FigPos(3)=FigWidth;
FigPos(4)=FigHeight;

set(InputFig,'Position',getnicedialoglocation(FigPos,get(InputFig,'Units')));

OKHandle=uicontrol(InputFig     ,              ...
                   BtnInfo      , ...
                   'Position'   ,[ FigWidth-2*BtnWidth-2*DefOffset DefOffset BtnWidth BtnHeight ] , ...
                   'KeyPressFcn',@doControlKeyPress , ...
                   'String'     ,'OK'        , ...
                   'Callback'   ,@doCallback , ...
                   'Tag'        ,'OK'        , ...
                   'UserData'   ,'OK'          ...
                   );

setdefaultbutton(InputFig, OKHandle);

CancelHandle=uicontrol(InputFig     ,              ...
                       BtnInfo      , ...
                       'Position'   ,[ FigWidth-BtnWidth-DefOffset DefOffset BtnWidth BtnHeight ]           , ...
                       'KeyPressFcn',@doControlKeyPress            , ...
                       'String'     ,'Cancel'    , ...
                       'Callback'   ,@doCallback , ...
                       'Tag'        ,'Cancel'    , ...
                       'UserData'   ,'Cancel'      ...
                       ); %#ok

handles = guihandles(InputFig);
handles.MinFigWidth = FigWidth;
handles.FigHeight   = FigHeight;
handles.TextMargin  = 2*DefOffset;
guidata(InputFig,handles);
set(InputFig,'ResizeFcn', {@doResize, inputWidthSpecified});

% make sure we are on screen
movegui(InputFig)

% if there is a figure out there and it's modal, we need to be modal too
if ~isempty(gcbf) && strcmp(get(gcbf,'WindowStyle'),'modal')
    set(InputFig,'WindowStyle','modal');
end

set(InputFig,'Visible','on');
drawnow;

if ~isempty(EditHandle)
    uicontrol(EditHandle(1));
end

uiwait(InputFig);

if ishandle(InputFig)
    Answer={};
    if strcmp(get(InputFig,'UserData'),'OK'),
        Answer=cell(NumQuest,1);
        for lp=1:NumQuest,
            Answer(lp)=get(EditHandle(lp),{'String'});
        end
    end
    delete(InputFig);
else
    Answer={};
end

% end

function doFigureKeyPress(obj, evd) %#ok
switch(evd.Key)
 case {'return','space'}
  set(gcbf,'UserData','OK');
  uiresume(gcbf);
 case {'escape'}
  delete(gcbf);
end

% end

function doControlKeyPress(obj, evd) 
switch(evd.Key)
 case {'return'}
  if ~strcmp(get(obj,'UserData'),'Cancel')
      set(gcbf,'UserData','OK');
      uiresume(gcbf);
  else
      delete(gcbf)
  end
 case 'escape'
  delete(gcbf)
end

% end

function doCallback(obj, evd) %#ok
if ~strcmp(get(obj,'UserData'),'Cancel')
    set(gcbf,'UserData','OK');
    uiresume(gcbf);
else
    delete(gcbf)
end

% end

function doEnter(obj, evd) %ok

h = get(obj,'Parent');
x = get(h,'CurrentCharacter');
if unicode2native(x) == 13
    doCallback(obj,evd);
end



function doResize(FigHandle, evd, multicolumn) %#ok
% TBD: Check difference in behavior w/ R13. May need to implement
% additional resize behavior/clean up.

Data=guidata(FigHandle);

resetPos = false; 

FigPos = get(FigHandle,'Position');
FigWidth = FigPos(3);
FigHeight = FigPos(4);

if FigWidth < Data.MinFigWidth
    FigWidth  = Data.MinFigWidth;
    FigPos(3) = Data.MinFigWidth;
    resetPos = true;
end

% make sure edit fields use all available space if 
% number of columns is not specified in dialog creation.
if ~multicolumn
    for lp = 1:length(Data.Edit)
        EditPos = get(Data.Edit(lp),'Position');
        EditPos(3) = FigWidth - Data.TextMargin;
        set(Data.Edit(lp),'Position',EditPos);
    end
end

if FigHeight ~= Data.FigHeight
    FigPos(4) = Data.FigHeight;
    resetPos = true;
end

if resetPos
    set(FigHandle,'Position',FigPos);  
end

% end

% set pixel width given the number of columns
function EditWidth = setcolumnwidth(object, rows, cols)
% Save current Units and String.
old_units = get(object, 'Units');
old_string = get(object, 'String');
old_position = get(object, 'Position');

set(object, 'Units', 'pixels')
set(object, 'String', char(ones(1,cols)*'x'));

new_extent = get(object,'Extent');
if (rows > 1)
    % For multiple rows, allow space for the scrollbar
    new_extent = new_extent + 19; % Width of the scrollbar
end
new_position = old_position;
new_position(3) = new_extent(3) + 1;
set(object, 'Position', new_position);

% reset string and units
set(object, 'String', old_string, 'Units', old_units);

EditWidth = new_extent(3);

% end

function figure_size = getnicedialoglocation(figure_size, figure_units)
% adjust the specified figure position to fig nicely over GCBF
% or into the upper 3rd of the screen

%  Copyright 1999-2010 The MathWorks, Inc.

parentHandle = gcbf;
convertData.destinationUnits = figure_units;
if ~isempty(parentHandle)
    % If there is a parent figure
    convertData.hFig = parentHandle;
    convertData.size = get(parentHandle,'Position');
    convertData.sourceUnits = get(parentHandle,'Units');  
    c = []; 
else
    % If there is no parent figure, use the root's data
    % and create a invisible figure as parent
    convertData.hFig = figure('visible','off');
    convertData.size = get(0,'ScreenSize');
    convertData.sourceUnits = get(0,'Units');
    c = onCleanup(@() close(convertData.hFig));
end

% Get the size of the dialog parent in the dialog units
container_size = hgconvertunits(convertData.hFig, convertData.size ,...
    convertData.sourceUnits, convertData.destinationUnits, get(convertData.hFig,'Parent'));

delete(c);

figure_size(1) = container_size(1)  + 1/2*(container_size(3) - figure_size(3));
figure_size(2) = container_size(2)  + 2/3*(container_size(4) - figure_size(4));

% end

function setdefaultbutton(figHandle, btnHandle)
% WARNING: This feature is not supported in MATLAB and the API and
% functionality may change in a future release.

%SETDEFAULTBUTTON Set default button for a figure.
%  SETDEFAULTBUTTON(BTNHANDLE) sets the button passed in to be the default button
%  (the button and callback used when the user hits "enter" or "return"
%  when in a dialog box.
%
%  This function is used by inputdlg.m, msgbox.m, questdlg.m and
%  uigetpref.m.
%
%  Example:
%
%  f = figure;
%  b1 = uicontrol('style', 'pushbutton', 'string', 'first', ...
%       'position', [100 100 50 20]);
%  b2 = uicontrol('style', 'pushbutton', 'string', 'second', ...
%       'position', [200 100 50 20]);
%  b3 = uicontrol('style', 'pushbutton', 'string', 'third', ...
%       'position', [300 100 50 20]);
%  setdefaultbutton(b2);
%

%  Copyright 2005-2007 The MathWorks, Inc.

%--------------------------------------- NOTE ------------------------------------------
% This file was copied into matlab/toolbox/local/private.
% These two files should be kept in sync - when editing please make sure
% that *both* files are modified.

% Nargin Check
narginchk(1,2)

if (usejava('awt') == 1)
    % We are running with Java Figures
    useJavaDefaultButton(figHandle, btnHandle)
else
    % We are running with Native Figures
    useHGDefaultButton(figHandle, btnHandle);
end

function useJavaDefaultButton(figH, btnH)
        % Get a UDD handle for the figure.
        fh = handle(figH);
        % Call the setDefaultButton method on the figure handle
        fh.setDefaultButton(btnH);


function useHGDefaultButton(figHandle, btnHandle)
        % First get the position of the button.
        btnPos = getpixelposition(btnHandle);

        % Next calculate offsets.
        leftOffset   = btnPos(1) - 1;
        bottomOffset = btnPos(2) - 2;
        widthOffset  = btnPos(3) + 3;
        heightOffset = btnPos(4) + 3;

        % Create the default button look with a uipanel.
        % Use black border color even on Mac or Windows-XP (XP scheme) since
        % this is in natve figures which uses the Win2K style buttons on Windows
        % and Motif buttons on the Mac.
        h1 = uipanel(get(btnHandle, 'Parent'), 'HighlightColor', 'black', ...
            'BorderType', 'etchedout', 'units', 'pixels', ...
            'Position', [leftOffset bottomOffset widthOffset heightOffset]);

        % Make sure it is stacked on the bottom.
        uistack(h1, 'bottom');


%% ========================================================================

function [scale]=colscale()%written by Pasteka, et al. (2012).

% clr file import
fid = fopen('color.clr');
fscanf(fid,'%s',1);
fscanf(fid,'%f',2);
C = fscanf(fid,'%f');
fclose(fid);

%colormap conversion to the matlab format
D = (reshape(C,4,numel(C)/4))';
scale=((D(:,2:4))/255);

%%

function cursorcoordinate(src,eventdata)%written by Pasteka, et al. (2012).

% find axes associated with calling window
hax = gca(src);     

% Axes limits
xlims = get(hax, 'XLim');
ylims = get(hax, 'YLim');

% format for x coordinate
if max(abs(xlims))>999999       %exponencial format definition for values over 10^6
   xformat_str          = 'X: %.2e,';
elseif max(abs(xlims))<0.1      %more precise format definition for values under 0.1
   xformat_str          = 'X: %.4f,';
else                            %standard format with 2 decimals
   xformat_str          = 'X: %.2f,';
end

% format for y coordinate
if max(abs(ylims))>999999
   yformat_str          = ' Y: %.2e';
elseif max(abs(ylims))<0.1
   yformat_str          = ' Y: %.4f';
else
   yformat_str          = ' Y: %.2f';
end

format_str=strcat(xformat_str,yformat_str);

% initial text string
curr_position   = get(hax, 'CurrentPoint');
position        = [curr_position(1, 1) curr_position(1, 2)];
position_string = sprintf(format_str, position); %position string as a text


% do not update if current mouse position is out of axes 
in_bounds = (position(1) >= xlims(1)) && ...
            (position(1) <= xlims(2)) && ...
            (position(2) >= ylims(1)) && ...
            (position(2) <= ylims(2));

if (~in_bounds)  
    return
end        

user_data = get(src, 'UserData'); 

%info text inicialization during the first callback call and its save 
%to the axes handle as as a UserData. Units were set to normalized to
%keep the relative position with axes

if ((~isfield(user_data, 'cursorcoordinate')) || ~ishandle(user_data.cursorcoordinate))

    user_data.cursorcoordinate = text(0, 0, 'blabla','Units','normalized','Parent',hax);

    set(src, 'UserData', user_data); % save to axes
end


%'online' text update
set(user_data.cursorcoordinate, 'Position', [0 -0.1],...
                           'String', position_string,...
                           'VerticalAlignment', 'bottom',...
                           'HorizontalAlignment', 'left',...
                           'Parent',hax);

                       

        
%% ======================================================================  
 
function [g,RowExt,ColExt] = cosxp2(T,perc)
%Expand grid using cosine taper mirror function, 'perc' (%) expansion. 
%where perc is a decimal that represents the expansion %, e.g. 0.15 --> 15% 
%g - final extrapolated field; RowExt - number of the added rows on one edge, ColExt - the same for columns
%Written by: Daniela Gerovska and Marcos Arauzo-Bravo (27/February/2003) 

if ~exist('perc')
    perc=0.1;   % default exapnsion is 10%
end
perc = 1+perc;

[NumRow,NumCol]=size(T);
%Deciding NumRowExt NumColExt
NumRowExt=Eve10Ext(NumRow,perc);
NumColExt=Eve10Ext(NumCol,perc);
g=T;
%Extention of the grid with half a cosine function
% Cosine taper right side
lim=NumColExt-NumCol; rlamb=lim+1; arg=pi/rlamb;
s=0.5*(g(:,NumCol)+g(:,1)); r=0.5*(g(:,NumCol)-g(:,1));
for k=1:lim
    ge=s+r*cos(arg*k);
    g(:,NumCol+k)=ge;
end
% Cosine taper left side
g = fliplr(g);
lim=NumColExt-NumCol; rlamb=lim+1; arg=pi/rlamb;
s=0.5*(g(:,NumColExt)+g(:,lim+1)); r=0.5*(g(:,NumColExt)-g(:,lim+1));
for k=1:lim
    ge=s+r*cos(arg*k);
    g(:,NumColExt+k)=ge;
end
g = fliplr(g);
% Cosine taper upper side
g=g';
lim=NumRowExt-NumRow; rlamb=lim+1; arg=pi/rlamb;
s=0.5*(g(:,NumRow)+g(:,1)); r=0.5*(g(:,NumRow)-g(:,1));
for k=1:lim
    ge=s+r*cos(arg*k);
    g(:,NumRow+k)=ge;
end
g=g';
% Cosine taper lower side
g = flipud(g); g=g';
lim=NumRowExt-NumRow; rlamb=lim+1; arg=pi/rlamb;
s=0.5*(g(:,NumRowExt)+g(:,lim+1)); r=0.5*(g(:,NumRowExt)-g(:,lim+1));
for k=1:lim
    ge=s+r*cos(arg*k);
    g(:,NumRowExt+k)=ge;
end
g=g'; g = flipud(g);
RowExt = NumRowExt - NumRow; ColExt = NumColExt - NumCol;

function NumEveExt=Eve10Ext(Num,perc)
%Even 'perc'(%) extension of the number Num
%Written by: Daniela Gerovska and Marcos Arauzo-Bravo (27/February/2003) 
 NumExt=perc*Num;
NumExtRou=round(NumExt);
if rem(NumExtRou,2)==1 
  DifPlu=abs(NumExt-(NumExtRou+1));
  DifMin=abs(NumExt-(NumExtRou-1));
    if DifPlu>DifMin
       NumEveExt=NumExtRou-1;
    else 
       NumEveExt=NumExtRou+1;
    end%if DifPlu>DifMin  
else
   NumEveExt=NumExtRou;   
end %if rem(NumExtRou,2)==1  

